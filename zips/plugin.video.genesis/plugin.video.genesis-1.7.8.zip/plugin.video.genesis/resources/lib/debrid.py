"""
Debrid Service Integration Module
Supports Real-Debrid, Premiumize, AllDebrid
Uses native urllib (no external requests module)
FIXED: Token persistence using file-based storage + cached torrent support
"""
import json
import time
import os
import xbmcgui
import xbmcaddon
import xbmc
import xbmcvfs

from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import urlencode

# Get fresh addon instance each time for settings
def get_addon():
    return xbmcaddon.Addon()

ADDON_ID = 'plugin.video.genesis'
ADDON_DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')

# Quality priorities (highest to lowest)
QUALITY_ORDER = ['2160p', '1080p', '720p', '480p', '360p']
USER_AGENT = 'Genesis Kodi Addon'

# Token files
RD_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'rd_token.json')
AD_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'ad_token.json')
PM_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'pm_token.json')
TB_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'tb_token.json')
LS_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'ls_token.json')


def _ensure_data_path():
    """Ensure addon data directory exists"""
    if not xbmcvfs.exists(ADDON_DATA_PATH):
        xbmcvfs.mkdirs(ADDON_DATA_PATH)
    if not os.path.exists(ADDON_DATA_PATH):
        os.makedirs(ADDON_DATA_PATH, exist_ok=True)


def _http(url, method='GET', data=None, headers=None, timeout=30):
    """HTTP helper - returns (status_code, parsed_json_or_text)"""
    hdrs = {'User-Agent': USER_AGENT}
    if headers:
        hdrs.update(headers)
    
    post_data = None
    if data is not None:
        if isinstance(data, dict):
            post_data = urlencode(data).encode('utf-8')
            hdrs.setdefault('Content-Type', 'application/x-www-form-urlencoded')
        elif isinstance(data, str):
            post_data = data.encode('utf-8')
        elif isinstance(data, bytes):
            post_data = data
    
    try:
        req = Request(url, data=post_data, headers=hdrs, method=method)
        resp = urlopen(req, timeout=timeout)
        body = resp.read().decode('utf-8', errors='replace')
        try:
            return resp.getcode(), json.loads(body)
        except json.JSONDecodeError:
            return resp.getcode(), body
    except HTTPError as e:
        body = ''
        try:
            body = e.read().decode('utf-8')
        except Exception:
            pass
        try:
            return e.code, json.loads(body)
        except Exception:
            return e.code, body
    except URLError as e:
        xbmc.log(f'Debrid URL Error: {e.reason}', xbmc.LOGERROR)
        return 0, None
    except Exception as e:
        xbmc.log(f'Debrid HTTP error: {e}', xbmc.LOGERROR)
        return 0, None


def _get(url, params=None, headers=None, timeout=30):
    """HTTP GET helper"""
    if params:
        query = urlencode(params)
        sep = '&' if '?' in url else '?'
        url = f'{url}{sep}{query}'
    return _http(url, method='GET', headers=headers, timeout=timeout)


def _post(url, data=None, params=None, headers=None, timeout=30):
    """HTTP POST helper"""
    if params:
        query = urlencode(params)
        sep = '&' if '?' in url else '?'
        url = f'{url}{sep}{query}'
    return _http(url, method='POST', data=data, headers=headers, timeout=timeout)


class RealDebrid:
    """Real-Debrid API integration using device auth with file-based token storage"""
    
    BASE_URL = "https://api.real-debrid.com/rest/1.0"
    OAUTH_URL = "https://api.real-debrid.com/oauth/v2"
    DEVICE_URL = "https://real-debrid.com/device"
    CLIENT_ID = "X245A4XAIBGVM"  # Public client ID for device auth
    
    def __init__(self):
        self._load_from_file()
    
    def _load_from_file(self):
        """Load tokens from file"""
        _ensure_data_path()
        
        self.token = ''
        self.refresh_token = ''
        self.client_id = self.CLIENT_ID
        self.client_secret = ''
        self.expires = 0
        
        if os.path.exists(RD_TOKEN_FILE):
            try:
                with open(RD_TOKEN_FILE, 'r') as f:
                    data = json.load(f)
                    self.token = data.get('access_token', '')
                    self.refresh_token = data.get('refresh_token', '')
                    self.client_id = data.get('client_id', self.CLIENT_ID)
                    self.client_secret = data.get('client_secret', '')
                    self.expires = float(data.get('expires', 0))
                    if self.token:
                        xbmc.log('Real-Debrid: Loaded tokens from file', xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f'Real-Debrid: Failed to load from file: {e}', xbmc.LOGWARNING)
        
        # Fallback to addon settings
        if not self.token:
            addon = get_addon()
            self.token = addon.getSetting('rd_access_token')
            self.refresh_token = addon.getSetting('rd_refresh_token')
            self.client_id = addon.getSetting('rd_client_id') or self.CLIENT_ID
            self.client_secret = addon.getSetting('rd_client_secret') or ''
            try:
                self.expires = float(addon.getSetting('rd_expires') or 0)
            except:
                self.expires = 0
    
    def _save_to_file(self):
        """Save tokens to file"""
        _ensure_data_path()
        
        data = {
            'access_token': self.token,
            'refresh_token': self.refresh_token,
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'expires': self.expires,
            'created_at': time.time()
        }
        
        try:
            with open(RD_TOKEN_FILE, 'w') as f:
                json.dump(data, f, indent=2)
            xbmc.log('Real-Debrid: Tokens saved to file', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'Real-Debrid: Failed to save to file: {e}', xbmc.LOGERROR)
        
        # Also save to addon settings as backup
        try:
            addon = get_addon()
            addon.setSetting('rd_access_token', self.token)
            addon.setSetting('rd_refresh_token', self.refresh_token)
            addon.setSetting('rd_client_id', self.client_id)
            addon.setSetting('rd_client_secret', self.client_secret)
            addon.setSetting('rd_expires', str(self.expires))
            addon.setSetting('rd_auth_done', 'true')
        except Exception as e:
            xbmc.log(f'Real-Debrid: Failed to save to addon settings: {e}', xbmc.LOGWARNING)
    
    def _auth_headers(self):
        return {'Authorization': f'Bearer {self.token}'}
    
    def is_authorized(self):
        """Check if Real-Debrid is authorized"""
        if not self.token:
            xbmc.log('Real-Debrid: No token found', xbmc.LOGDEBUG)
            return False
        
        # Check if token needs refresh (10 min buffer)
        if self.expires and time.time() > self.expires - 600:
            xbmc.log('Real-Debrid: Token near expiry, refreshing...', xbmc.LOGINFO)
            refreshed = self._refresh_token()
            if not refreshed:
                # Token refresh failed, but token might still work
                # Try a quick API call to verify
                xbmc.log('Real-Debrid: Refresh failed, testing current token...', xbmc.LOGINFO)
                try:
                    status, result = _get(
                        f"{self.BASE_URL}/user",
                        headers=self._auth_headers()
                    )
                    if status == 200:
                        xbmc.log('Real-Debrid: Token still valid despite refresh failure', xbmc.LOGINFO)
                        return True
                except:
                    pass
                xbmc.log('Real-Debrid: Token expired and refresh failed', xbmc.LOGWARNING)
                return False
            return True
        
        xbmc.log('Real-Debrid: Authorization valid', xbmc.LOGDEBUG)
        return True
    
    def _refresh_token(self):
        """Refresh the access token"""
        if not self.refresh_token or not self.client_secret:
            return False
        
        try:
            data = {
                'client_id': self.client_id,
                'client_secret': self.client_secret,
                'code': self.refresh_token,
                'grant_type': 'http://oauth.net/grant_type/device/1.0'
            }
            
            status, result = _post(f'{self.OAUTH_URL}/token', data=data)
            
            if status == 200 and isinstance(result, dict) and 'access_token' in result:
                self.token = result['access_token']
                self.refresh_token = result.get('refresh_token', self.refresh_token)
                self.expires = time.time() + result.get('expires_in', 86400)
                
                self._save_to_file()
                xbmc.log('Real-Debrid: Token refreshed successfully', xbmc.LOGINFO)
                return True
        except Exception as e:
            xbmc.log(f'Real-Debrid refresh error: {e}', xbmc.LOGERROR)
        
        return False
    
    def authorize(self):
        """Device code authorization flow"""
        try:
            # Step 1: Get device code
            xbmc.log('Real-Debrid: Requesting device code...', xbmc.LOGINFO)
            
            status, result = _get(
                f"{self.OAUTH_URL}/device/code",
                params={"client_id": self.CLIENT_ID, "new_credentials": "yes"}
            )
            
            if status != 200 or not isinstance(result, dict):
                xbmc.log(f'Real-Debrid: Failed to get device code - Status: {status}', xbmc.LOGERROR)
                xbmcgui.Dialog().notification('Error', 'Failed to get device code', xbmcgui.NOTIFICATION_ERROR)
                return False
            
            device_code = result.get('device_code')
            user_code = result.get('user_code')
            verification_url = result.get('verification_url', self.DEVICE_URL)
            expires_in = result.get('expires_in', 600)
            interval = result.get('interval', 5)
            
            if not device_code or not user_code:
                xbmcgui.Dialog().notification('Error', 'Invalid response from Real-Debrid', xbmcgui.NOTIFICATION_ERROR)
                return False
            
            xbmc.log(f'Real-Debrid: Got device code, user_code: {user_code}', xbmc.LOGINFO)
            
            # Step 2: Show dialog
            dialog = xbmcgui.DialogProgress()
            dialog.create(
                "Real-Debrid Authorization",
                f"Go to: [B][COLOR skyblue]{verification_url}[/COLOR][/B]\n\n"
                f"Enter Code: [B][COLOR yellow]{user_code}[/COLOR][/B]\n\n"
                f"Waiting for authorization..."
            )
            
            # Step 3: Poll for credentials
            start = time.time()
            while time.time() - start < expires_in:
                if dialog.iscanceled():
                    dialog.close()
                    return False
                
                elapsed = time.time() - start
                remaining = expires_in - elapsed
                progress = int((elapsed / expires_in) * 100)
                dialog.update(
                    progress,
                    f"Go to: [B][COLOR skyblue]{verification_url}[/COLOR][/B]\n\n"
                    f"Enter Code: [B][COLOR yellow]{user_code}[/COLOR][/B]\n\n"
                    f"Time remaining: {int(remaining)} seconds"
                )
                
                time.sleep(interval)
                
                # Check credentials
                check_status, check_result = _get(
                    f"{self.OAUTH_URL}/device/credentials",
                    params={"client_id": self.CLIENT_ID, "code": device_code}
                )
                
                if check_status == 200 and isinstance(check_result, dict) and 'client_id' in check_result:
                    # Got credentials, now get access token
                    client_id = check_result.get('client_id')
                    client_secret = check_result.get('client_secret')
                    
                    token_data = {
                        "client_id": client_id,
                        "client_secret": client_secret,
                        "code": device_code,
                        "grant_type": "http://oauth.net/grant_type/device/1.0"
                    }
                    
                    tok_status, tok_result = _post(f"{self.OAUTH_URL}/token", data=token_data)
                    
                    if tok_status == 200 and isinstance(tok_result, dict) and 'access_token' in tok_result:
                        self.token = tok_result.get('access_token', '')
                        self.refresh_token = tok_result.get('refresh_token', '')
                        self.client_id = client_id
                        self.client_secret = client_secret
                        self.expires = time.time() + tok_result.get('expires_in', 86400)
                        
                        self._save_to_file()
                        
                        dialog.close()
                        xbmcgui.Dialog().notification("Success!", "Real-Debrid linked!", xbmcgui.NOTIFICATION_INFO)
                        xbmc.log('Real-Debrid: Authorization successful', xbmc.LOGINFO)
                        return True
            
            dialog.close()
            xbmcgui.Dialog().notification('Timeout', 'Authorization timed out', xbmcgui.NOTIFICATION_WARNING)
            return False
            
        except Exception as e:
            xbmc.log(f"RD auth error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Error', f'Auth failed: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
            return False
    
    def check_cache(self, hashes):
        """Check if torrents are cached on Real-Debrid.

        NOTE: Real-Debrid retired the /torrents/instantAvailability endpoint in mid-2024.
        It now consistently returns an empty object for every hash, so any badge
        relying on this signal will never light up. We keep the call (cheap & safe)
        in case RD re-enables it, but treat empty responses as "unknown" rather
        than "uncached". Downstream code falls back to a fast add-and-probe.
        """
        if not self.is_authorized() or not hashes:
            return {}
        try:
            hash_str = '/'.join(hashes[:100])
            status, result = _get(
                f"{self.BASE_URL}/torrents/instantAvailability/{hash_str}",
                headers=self._auth_headers(),
                timeout=8
            )
            if status == 200 and isinstance(result, dict) and result:
                cached = {}
                for hash_key, value in result.items():
                    if value and isinstance(value, dict):
                        rd_data = value.get('rd', [])
                        if rd_data:
                            cached[hash_key.lower()] = rd_data
                if cached:
                    return cached
            # Endpoint deprecated / empty payload
            xbmc.log('RD instantAvailability returned no cache data (endpoint deprecated)', xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f'RD cache check error: {e}', xbmc.LOGDEBUG)
        return {}
    
    def unrestrict_link(self, link):
        """Convert link to direct stream URL"""
        if not self.is_authorized():
            return None
        try:
            status, result = _post(
                f"{self.BASE_URL}/unrestrict/link",
                data={"link": link},
                headers=self._auth_headers()
            )
            if isinstance(result, dict):
                return result.get('download')
        except Exception as e:
            xbmc.log(f'RD unrestrict error: {e}', xbmc.LOGERROR)
        return None
    
    VIDEO_EXTS = ('.mkv', '.mp4', '.avi', '.mov', '.m4v', '.ts', '.m2ts', '.wmv', '.flv', '.webm', '.mpg', '.mpeg')
    SAMPLE_TERMS = ('sample', 'rarbg.txt', 'screens/', 'extras/', 'featurette', 'trailer', 'bonus', 'deleted.scene')

    def _delete_torrent(self, torrent_id):
        try:
            _http(
                f"{self.BASE_URL}/torrents/delete/{torrent_id}",
                method='DELETE',
                headers=self._auth_headers(),
                timeout=10
            )
        except Exception:
            pass

    def _select_best_file_ids(self, info):
        """Return comma-separated file ids of the largest video file(s) in a torrent.

        Filters out samples / extras / non-video and selects the single biggest
        video file. If only non-video files exist, returns 'all' as a fallback.
        """
        files = info.get('files', []) or []
        if not files:
            return 'all'

        candidates = []
        for f in files:
            path = (f.get('path') or '').lower()
            name = path.rsplit('/', 1)[-1]
            if not name.endswith(self.VIDEO_EXTS):
                continue
            if any(term in path for term in self.SAMPLE_TERMS):
                continue
            candidates.append(f)

        if not candidates:
            # No clean videos -> fall back to keeping all so RD still completes
            return 'all'

        # Pick the single biggest file (movies & per-episode picks)
        candidates.sort(key=lambda x: int(x.get('bytes', 0) or 0), reverse=True)
        return str(candidates[0].get('id'))

    def add_magnet(self, magnet, check_cache_first=True):
        """Add magnet, select the largest video file, return a playable URL.

        Strategy:
          1. Add magnet -> get torrent id, file list
          2. Pick largest non-sample video file and selectFiles on JUST that file
          3. Quick-probe ~4s: if torrent goes to 'downloaded' instantly, it was
             cached. If not, give up fast so the user can try the next source
             (RD will not finish downloading in-session anyway).
          4. On any failure or non-cached, delete the torrent to keep the
             account tidy and try the next source.
        """
        if not self.is_authorized():
            return None

        torrent_id = None
        try:
            # Add magnet
            status, result = _post(
                f"{self.BASE_URL}/torrents/addMagnet",
                data={"magnet": magnet},
                headers=self._auth_headers(),
                timeout=20
            )
            if not isinstance(result, dict) or 'id' not in result:
                xbmc.log(f'RD addMagnet failed: {result}', xbmc.LOGERROR)
                return None
            torrent_id = result.get('id')

            # Get file list (need to wait briefly for RD to magnetize)
            info = None
            for _ in range(8):
                _, info = _get(
                    f"{self.BASE_URL}/torrents/info/{torrent_id}",
                    headers=self._auth_headers(),
                    timeout=10
                )
                if isinstance(info, dict) and info.get('files'):
                    break
                time.sleep(0.5)

            if not isinstance(info, dict):
                self._delete_torrent(torrent_id)
                return None

            file_ids = self._select_best_file_ids(info)
            _post(
                f"{self.BASE_URL}/torrents/selectFiles/{torrent_id}",
                data={"files": file_ids},
                headers=self._auth_headers(),
                timeout=10
            )

            # Quick cached probe: poll every 0.5s for ~6s. If not cached, abort.
            quick_attempts = 12
            for _ in range(quick_attempts):
                _, info = _get(
                    f"{self.BASE_URL}/torrents/info/{torrent_id}",
                    headers=self._auth_headers(),
                    timeout=10
                )
                if isinstance(info, dict):
                    s = info.get('status', '')
                    if s == 'downloaded':
                        links = info.get('links', [])
                        if links:
                            return self.unrestrict_link(links[0])
                        # No links yet but downloaded -> give RD one more tick
                    elif s in ('error', 'dead', 'magnet_error', 'virus'):
                        xbmc.log(f'RD torrent status: {s}', xbmc.LOGWARNING)
                        self._delete_torrent(torrent_id)
                        return None
                time.sleep(0.5)

            # Not cached - don't waste user's time waiting for RD download
            xbmc.log('RD: source is not cached - aborting (try next source)', xbmc.LOGINFO)
            self._delete_torrent(torrent_id)
            return None

        except Exception as e:
            xbmc.log(f'RD magnet error: {e}', xbmc.LOGERROR)
            if torrent_id:
                self._delete_torrent(torrent_id)
            return None
    
    def revoke(self):
        """Clear all Real-Debrid tokens"""
        # Clear file
        if os.path.exists(RD_TOKEN_FILE):
            try:
                os.remove(RD_TOKEN_FILE)
            except:
                pass
        
        # Clear addon settings
        try:
            addon = get_addon()
            addon.setSetting('rd_access_token', '')
            addon.setSetting('rd_refresh_token', '')
            addon.setSetting('rd_client_id', '')
            addon.setSetting('rd_client_secret', '')
            addon.setSetting('rd_expires', '0')
            addon.setSetting('rd_auth_done', 'false')
        except:
            pass
        
        self.token = ''
        self.refresh_token = ''
        xbmcgui.Dialog().notification("Real-Debrid", "Account unlinked", xbmcgui.NOTIFICATION_INFO)

    def account_info(self):
        """Get Real-Debrid account info (username, type, expiry, points)"""
        if not self.token:
            return {}
        try:
            status, result = _get(
                f"{self.BASE_URL}/user",
                headers=self._auth_headers()
            )
            if status == 200 and isinstance(result, dict):
                expiration = result.get('expiration', '')
                days_left = 0
                if expiration:
                    try:
                        from datetime import datetime
                        exp_date = datetime.strptime(expiration, '%Y-%m-%dT%H:%M:%S.%fZ')
                        delta = exp_date - datetime.utcnow()
                        days_left = max(0, delta.days)
                    except Exception:
                        try:
                            from datetime import datetime
                            exp_date = datetime.strptime(expiration[:19], '%Y-%m-%dT%H:%M:%S')
                            delta = exp_date - datetime.utcnow()
                            days_left = max(0, delta.days)
                        except:
                            pass

                return {
                    'username': result.get('username', ''),
                    'email': result.get('email', ''),
                    'type': result.get('type', 'free'),
                    'premium': result.get('type', '') == 'premium',
                    'expiration': expiration,
                    'days_left': days_left,
                    'points': result.get('points', 0),
                }
            elif status == 401:
                # Token invalid, try refresh
                if self._refresh_token():
                    return self.account_info()
                return {'type': 'expired', 'premium': False, 'days_left': 0,
                        'expiration': 'Token expired - re-authorize'}
        except Exception as e:
            xbmc.log(f'RD account_info error: {e}', xbmc.LOGERROR)
        return {}


class AllDebrid:
    """AllDebrid API integration with file-based token storage"""
    
    BASE_URL = "https://api.alldebrid.com/v4"
    DEVICE_URL = "https://alldebrid.com/pin/"
    AGENT = "Genesis"
    
    def __init__(self):
        self._load_from_file()
    
    def _load_from_file(self):
        """Load token from file"""
        _ensure_data_path()
        self.token = ''
        
        if os.path.exists(AD_TOKEN_FILE):
            try:
                with open(AD_TOKEN_FILE, 'r') as f:
                    data = json.load(f)
                    self.token = data.get('api_key', '')
                    if self.token:
                        xbmc.log('AllDebrid: Loaded token from file', xbmc.LOGDEBUG)
            except:
                pass
        
        if not self.token:
            self.token = get_addon().getSetting('ad_api_key')
    
    def _save_to_file(self):
        """Save token to file"""
        _ensure_data_path()
        try:
            with open(AD_TOKEN_FILE, 'w') as f:
                json.dump({'api_key': self.token, 'created_at': time.time()}, f)
            addon = get_addon()
            addon.setSetting('ad_api_key', self.token)
            addon.setSetting('ad_auth_done', 'true')
        except:
            pass
    
    def is_authorized(self):
        return bool(self.token)
    
    def authorize(self):
        """PIN-based authorization"""
        try:
            xbmc.log('AllDebrid: Requesting PIN...', xbmc.LOGINFO)
            
            status, result = _get(
                f"{self.BASE_URL}/pin/get",
                params={"agent": self.AGENT}
            )
            
            if not isinstance(result, dict) or result.get('status') != 'success':
                xbmc.log(f'AllDebrid: Failed to get PIN - {result}', xbmc.LOGERROR)
                xbmcgui.Dialog().notification('Error', 'Failed to get PIN', xbmcgui.NOTIFICATION_ERROR)
                return False
            
            data = result.get('data', {})
            pin = data.get('pin')
            check_url = data.get('check_url')
            user_url = data.get('user_url', self.DEVICE_URL)
            expires_in = data.get('expires_in', 600)
            
            if not pin:
                xbmcgui.Dialog().notification('Error', 'Invalid PIN response', xbmcgui.NOTIFICATION_ERROR)
                return False
            
            xbmc.log(f'AllDebrid: Got PIN: {pin}', xbmc.LOGINFO)
            
            dialog = xbmcgui.DialogProgress()
            dialog.create(
                "AllDebrid Authorization",
                f"Go to: [B][COLOR skyblue]{user_url}[/COLOR][/B]\n\n"
                f"Enter PIN: [B][COLOR yellow]{pin}[/COLOR][/B]\n\n"
                f"Waiting for authorization..."
            )
            
            start = time.time()
            while time.time() - start < expires_in:
                if dialog.iscanceled():
                    dialog.close()
                    return False
                
                elapsed = time.time() - start
                remaining = expires_in - elapsed
                progress = int((elapsed / expires_in) * 100)
                dialog.update(
                    progress,
                    f"Go to: [B][COLOR skyblue]{user_url}[/COLOR][/B]\n\n"
                    f"Enter PIN: [B][COLOR yellow]{pin}[/COLOR][/B]\n\n"
                    f"Time remaining: {int(remaining)} seconds"
                )
                
                time.sleep(5)
                
                check_status, check_result = _get(check_url, params={"agent": self.AGENT})
                
                if isinstance(check_result, dict) and check_result.get('status') == 'success':
                    api_key = check_result.get('data', {}).get('apikey')
                    if api_key:
                        self.token = api_key
                        self._save_to_file()
                        dialog.close()
                        xbmcgui.Dialog().notification("Success!", "AllDebrid linked!", xbmcgui.NOTIFICATION_INFO)
                        xbmc.log('AllDebrid: Authorization successful', xbmc.LOGINFO)
                        return True
            
            dialog.close()
            xbmcgui.Dialog().notification('Timeout', 'Authorization timed out', xbmcgui.NOTIFICATION_WARNING)
            return False
            
        except Exception as e:
            xbmc.log(f"AD auth error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Error', f'Auth failed: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
            return False
    
    def check_cache(self, magnets):
        """Check if magnets are cached on AllDebrid.

        NOTE: AllDebrid deprecated the /magnet/instant endpoint in early 2024.
        The endpoint now returns an error / empty response. Kept as a no-op
        so the resolver can still attempt a fast add-and-probe.
        """
        if not self.is_authorized() or not magnets:
            return {}
        try:
            params = {"agent": self.AGENT, "apikey": self.token}
            for i, m in enumerate(magnets[:50]):
                params[f'magnets[{i}]'] = m
            status, result = _get(f"{self.BASE_URL}/magnet/instant", params=params, timeout=8)
            if isinstance(result, dict) and result.get('status') == 'success':
                cached = {}
                data = result.get('data', {}).get('magnets', [])
                for item in data:
                    if item.get('instant'):
                        cached[item.get('hash', '').lower()] = True
                if cached:
                    return cached
            xbmc.log('AD /magnet/instant returned no cache data (endpoint deprecated)', xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f'AD cache check error: {e}', xbmc.LOGDEBUG)
        return {}
    
    def unrestrict_link(self, link):
        if not self.is_authorized():
            return None
        try:
            status, result = _get(
                f"{self.BASE_URL}/link/unlock",
                params={"agent": self.AGENT, "apikey": self.token, "link": link}
            )
            if isinstance(result, dict) and result.get('status') == 'success':
                return result.get('data', {}).get('link')
        except Exception as e:
            xbmc.log(f'AD unrestrict error: {e}', xbmc.LOGERROR)
        return None
    
    AD_VIDEO_EXTS = ('.mkv', '.mp4', '.avi', '.mov', '.m4v', '.ts', '.m2ts', '.wmv', '.flv', '.webm', '.mpg', '.mpeg')
    AD_SAMPLE_TERMS = ('sample', 'rarbg.txt', 'screens', 'extras', 'featurette', 'trailer', 'bonus')

    def _ad_delete_magnet(self, magnet_id):
        try:
            _get(
                f"{self.BASE_URL}/magnet/delete",
                params={"agent": self.AGENT, "apikey": self.token, "id": magnet_id},
                timeout=8
            )
        except Exception:
            pass

    def _ad_pick_best_link(self, links):
        """Pick the largest non-sample video link from AD magnet status response."""
        if not links:
            return None

        def name_of(item):
            return ((item.get('filename') or item.get('name') or '').lower())

        def size_of(item):
            try:
                return int(item.get('size', 0) or 0)
            except Exception:
                return 0

        videos = [item for item in links if name_of(item).endswith(self.AD_VIDEO_EXTS)
                  and not any(t in name_of(item) for t in self.AD_SAMPLE_TERMS)]
        if videos:
            videos.sort(key=size_of, reverse=True)
            return videos[0].get('link')
        # fallback - just first link
        return links[0].get('link')

    def add_magnet(self, magnet, check_cache_first=True):
        """Add magnet, pick the largest video file, quick-probe if cached."""
        if not self.is_authorized():
            return None
        magnet_id = None
        try:
            status, result = _get(
                f"{self.BASE_URL}/magnet/upload",
                params={"agent": self.AGENT, "apikey": self.token, "magnets[]": magnet},
                timeout=15
            )
            if not isinstance(result, dict) or result.get('status') != 'success':
                return None
            magnet_id = result.get('data', {}).get('magnets', [{}])[0].get('id')
            if not magnet_id:
                return None

            # Quick poll: 0.5s x 16 = 8s. If not Ready, abort.
            for _ in range(16):
                _, status_result = _get(
                    f"{self.BASE_URL}/magnet/status",
                    params={"agent": self.AGENT, "apikey": self.token, "id": magnet_id},
                    timeout=10
                )
                if isinstance(status_result, dict) and status_result.get('status') == 'success':
                    magnet_data = status_result.get('data', {}).get('magnets', {})
                    state = magnet_data.get('status', '')
                    if state == 'Ready':
                        links = magnet_data.get('links', [])
                        best = self._ad_pick_best_link(links)
                        if best:
                            return self.unrestrict_link(best)
                    elif state in ('Error', 'Dead', 'File error'):
                        self._ad_delete_magnet(magnet_id)
                        return None
                time.sleep(0.5)

            xbmc.log('AD: source is not cached - aborting (try next source)', xbmc.LOGINFO)
            self._ad_delete_magnet(magnet_id)
            return None
        except Exception as e:
            xbmc.log(f'AD magnet error: {e}', xbmc.LOGERROR)
            if magnet_id:
                self._ad_delete_magnet(magnet_id)
            return None
    
    def revoke(self):
        if os.path.exists(AD_TOKEN_FILE):
            try:
                os.remove(AD_TOKEN_FILE)
            except:
                pass
        
        addon = get_addon()
        addon.setSetting('ad_api_key', '')
        addon.setSetting('ad_auth_done', 'false')
        self.token = ''
        xbmcgui.Dialog().notification("AllDebrid", "Account unlinked", xbmcgui.NOTIFICATION_INFO)

    def account_info(self):
        """Get AllDebrid account info"""
        if not self.token:
            return {}
        try:
            status, result = _get(
                f"{self.BASE_URL}/user",
                params={"agent": self.AGENT, "apikey": self.token}
            )
            if isinstance(result, dict) and result.get('status') == 'success':
                data = result.get('data', {}).get('user', {})
                premium_until = data.get('premiumUntil', 0)
                days_left = 0
                exp_str = 'Unknown'
                if premium_until:
                    try:
                        from datetime import datetime
                        exp_date = datetime.utcfromtimestamp(premium_until)
                        delta = exp_date - datetime.utcnow()
                        days_left = max(0, delta.days)
                        exp_str = exp_date.strftime('%Y-%m-%d')
                    except:
                        pass
                return {
                    'username': data.get('username', ''),
                    'email': data.get('email', ''),
                    'type': 'premium' if data.get('isPremium') else 'free',
                    'premium': bool(data.get('isPremium')),
                    'expiration': exp_str,
                    'days_left': days_left,
                }
        except Exception as e:
            xbmc.log(f'AD account_info error: {e}', xbmc.LOGERROR)
        return {}


class Premiumize:
    """Premiumize API integration with file-based token storage"""
    
    BASE_URL = "https://www.premiumize.me/api"
    TOKEN_URL = "https://www.premiumize.me/token"  # OAuth token endpoint (NOT /api/token)
    DEVICE_URL = "https://www.premiumize.me/device"
    # Public client credentials for device auth
    CLIENT_ID = "662875953"
    CLIENT_SECRET = "xmg33m74n6t6x8phun"
    
    def __init__(self):
        self._load_from_file()
    
    def _load_from_file(self):
        """Load token from file"""
        _ensure_data_path()
        self.token = ''
        
        if os.path.exists(PM_TOKEN_FILE):
            try:
                with open(PM_TOKEN_FILE, 'r') as f:
                    data = json.load(f)
                    self.token = data.get('access_token', '')
                    if self.token:
                        xbmc.log('Premiumize: Loaded token from file', xbmc.LOGDEBUG)
            except:
                pass
        
        if not self.token:
            self.token = get_addon().getSetting('pm_access_token')
    
    def _save_to_file(self):
        """Save token to file"""
        _ensure_data_path()
        try:
            with open(PM_TOKEN_FILE, 'w') as f:
                json.dump({'access_token': self.token, 'created_at': time.time()}, f)
            addon = get_addon()
            addon.setSetting('pm_access_token', self.token)
            addon.setSetting('pm_auth_done', 'true')
        except:
            pass
    
    def is_authorized(self):
        return bool(self.token)
    
    def authorize(self):
        """OAuth device authorization - using correct Premiumize.me OAuth flow"""
        try:
            xbmc.log('Premiumize: Requesting device code...', xbmc.LOGINFO)
            
            # Step 1: Request device code using response_type=device_code
            # Important: Use TOKEN_URL (www.premiumize.me/token), NOT /api/token
            status, result = _post(
                self.TOKEN_URL,
                data={
                    "client_id": self.CLIENT_ID,
                    "response_type": "device_code"
                }
            )
            
            xbmc.log(f'Premiumize: Device code response - Status: {status}, Result: {result}', xbmc.LOGDEBUG)
            
            if not isinstance(result, dict) or not result.get('device_code'):
                error_msg = result.get('error', 'Unknown error') if isinstance(result, dict) else str(result)
                xbmc.log(f'Premiumize: Failed to get device code - {error_msg}', xbmc.LOGERROR)
                xbmcgui.Dialog().notification('Error', 'Failed to get device code', xbmcgui.NOTIFICATION_ERROR)
                return False
            
            device_code = result.get('device_code')
            user_code = result.get('user_code')
            verification_url = result.get('verification_uri', self.DEVICE_URL)
            expires_in = int(result.get('expires_in', 600))
            interval = int(result.get('interval', 5))
            
            xbmc.log(f'Premiumize: Got device code, user_code: {user_code}, verification_uri: {verification_url}', xbmc.LOGINFO)
            
            dialog = xbmcgui.DialogProgress()
            dialog.create(
                "Premiumize Authorization",
                f"Go to: [B][COLOR skyblue]{verification_url}[/COLOR][/B]\n\n"
                f"Enter Code: [B][COLOR yellow]{user_code}[/COLOR][/B]\n\n"
                f"Waiting for authorization..."
            )
            
            start = time.time()
            token_ttl = expires_in
            
            while token_ttl > 0:
                if dialog.iscanceled():
                    dialog.close()
                    return False
                
                elapsed = time.time() - start
                remaining = expires_in - elapsed
                progress = int(100 - (elapsed / expires_in) * 100)
                dialog.update(
                    progress,
                    f"Go to: [B][COLOR skyblue]{verification_url}[/COLOR][/B]\n\n"
                    f"Enter Code: [B][COLOR yellow]{user_code}[/COLOR][/B]\n\n"
                    f"Time remaining: {int(remaining)} seconds"
                )
                
                # Wait for interval before polling
                time.sleep(interval)
                token_ttl -= interval
                
                # Step 2: Poll for token using grant_type=device_code and code parameter
                check_status, check_result = _post(
                    self.TOKEN_URL,
                    data={
                        "client_id": self.CLIENT_ID,
                        "code": device_code,
                        "grant_type": "device_code"
                    }
                )
                
                xbmc.log(f'Premiumize: Poll response - Status: {check_status}, Result: {check_result}', xbmc.LOGDEBUG)
                
                if isinstance(check_result, dict):
                    # Check for access token (success)
                    if check_result.get('access_token'):
                        self.token = check_result.get('access_token')
                        self._save_to_file()
                        dialog.close()
                        xbmcgui.Dialog().notification("Success!", "Premiumize linked!", xbmcgui.NOTIFICATION_INFO)
                        xbmc.log('Premiumize: Authorization successful', xbmc.LOGINFO)
                        return True
                    
                    # Check for errors
                    error = check_result.get('error', '')
                    if error == 'access_denied':
                        dialog.close()
                        xbmcgui.Dialog().notification('Denied', 'Authorization was denied', xbmcgui.NOTIFICATION_WARNING)
                        return False
                    # If error is 'authorization_pending' or similar, continue polling
            
            dialog.close()
            xbmcgui.Dialog().notification('Timeout', 'Authorization timed out', xbmcgui.NOTIFICATION_WARNING)
            return False
            
        except Exception as e:
            xbmc.log(f"PM auth error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Error', f'Auth failed: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
            return False
    
    def check_cache(self, hashes):
        """Check if files are cached on Premiumize"""
        if not self.is_authorized() or not hashes:
            return {}
        
        try:
            # PM uses items[] array
            params = {"items[]": hashes[:100]}
            status, result = _post(
                f"{self.BASE_URL}/cache/check",
                headers={"Authorization": f"Bearer {self.token}"},
                data=params
            )
            
            if isinstance(result, dict) and result.get('status') == 'success':
                response = result.get('response', [])
                cached = {}
                for i, is_cached in enumerate(response):
                    if is_cached and i < len(hashes):
                        cached[hashes[i].lower()] = True
                return cached
        except Exception as e:
            xbmc.log(f'PM cache check error: {e}', xbmc.LOGERROR)
        
        return {}
    
    def unrestrict_link(self, link):
        if not self.is_authorized():
            return None
        try:
            status, result = _post(
                f"{self.BASE_URL}/transfer/directdl",
                headers={"Authorization": f"Bearer {self.token}"},
                data={"src": link}
            )
            if isinstance(result, dict) and result.get('status') == 'success':
                content = result.get('content', [])
                if content:
                    return content[0].get('link')
        except Exception as e:
            xbmc.log(f'PM unrestrict error: {e}', xbmc.LOGERROR)
        return None
    
    def add_magnet(self, magnet, check_cache_first=True):
        return self.unrestrict_link(magnet)
    
    def revoke(self):
        if os.path.exists(PM_TOKEN_FILE):
            try:
                os.remove(PM_TOKEN_FILE)
            except:
                pass
        
        addon = get_addon()
        addon.setSetting('pm_access_token', '')
        addon.setSetting('pm_auth_done', 'false')
        self.token = ''
        xbmcgui.Dialog().notification("Premiumize", "Account unlinked", xbmcgui.NOTIFICATION_INFO)

    def account_info(self):
        """Get Premiumize account info"""
        if not self.token:
            return {}
        try:
            status, result = _get(
                f"{self.BASE_URL}/account/info",
                headers={"Authorization": f"Bearer {self.token}"}
            )
            if status == 200 and isinstance(result, dict) and result.get('status') == 'success':
                premium_until = result.get('premium_until', 0)
                days_left = 0
                exp_str = 'Unknown'
                if premium_until:
                    try:
                        from datetime import datetime
                        exp_date = datetime.utcfromtimestamp(premium_until)
                        delta = exp_date - datetime.utcnow()
                        days_left = max(0, delta.days)
                        exp_str = exp_date.strftime('%Y-%m-%d')
                    except:
                        pass
                return {
                    'username': str(result.get('customer_id', '')),
                    'type': 'premium' if premium_until else 'free',
                    'premium': bool(premium_until and days_left > 0),
                    'expiration': exp_str,
                    'days_left': days_left,
                    'space_used': result.get('space_used', 0),
                    'limit_used': result.get('limit_used', 0),
                }
            elif status == 401:
                return {'type': 'expired', 'premium': False, 'days_left': 0,
                        'expiration': 'Token expired - re-authorize'}
        except Exception as e:
            xbmc.log(f'PM account_info error: {e}', xbmc.LOGERROR)
        return {}

    # ------------------------------------------------------------------
    # Generic auth header
    # ------------------------------------------------------------------
    def _auth_headers(self):
        return {"Authorization": f"Bearer {self.token}"}

    # ------------------------------------------------------------------
    # FOLDER MANAGEMENT
    # ------------------------------------------------------------------
    def folder_list(self, folder_id=None, include_breadcrumbs=True):
        """List items in a folder. Returns dict with content + breadcrumbs."""
        if not self.is_authorized():
            return {}
        params = {}
        if folder_id:
            params['id'] = folder_id
        if include_breadcrumbs:
            params['includebreadcrumbs'] = 'true'
        status, result = _get(f"{self.BASE_URL}/folder/list",
                              params=params, headers=self._auth_headers())
        if isinstance(result, dict) and result.get('status') == 'success':
            return result
        return {}

    def folder_create(self, name, parent_id=None):
        """Create a folder. Returns new folder id or None."""
        if not self.is_authorized() or not name:
            return None
        data = {'name': name}
        if parent_id:
            data['parent_id'] = parent_id
        status, result = _post(f"{self.BASE_URL}/folder/create",
                               data=data, headers=self._auth_headers())
        if isinstance(result, dict) and result.get('status') == 'success':
            return result.get('id') or True
        return None

    def folder_delete(self, folder_id):
        if not self.is_authorized() or not folder_id:
            return False
        status, result = _post(f"{self.BASE_URL}/folder/delete",
                               data={'id': folder_id},
                               headers=self._auth_headers())
        return isinstance(result, dict) and result.get('status') == 'success'

    def folder_rename(self, folder_id, name):
        if not self.is_authorized() or not folder_id or not name:
            return False
        status, result = _post(f"{self.BASE_URL}/folder/rename",
                               data={'id': folder_id, 'name': name},
                               headers=self._auth_headers())
        return isinstance(result, dict) and result.get('status') == 'success'

    def folder_paste(self, target_folder_id, item_ids=None, folder_ids=None):
        """Move items / folders to target_folder_id (root = '0' or '')."""
        if not self.is_authorized():
            return False
        items = item_ids or []
        folders = folder_ids or []
        # urlencode with same-key repeats
        from urllib.parse import urlencode as _ue
        body_parts = [('id', target_folder_id or '0')]
        for i in items:
            body_parts.append(('items[]', i))
        for f in folders:
            body_parts.append(('folders[]', f))
        body = _ue(body_parts).encode('utf-8')
        status, result = _http(f"{self.BASE_URL}/folder/paste",
                               method='POST', data=body,
                               headers=self._auth_headers())
        return isinstance(result, dict) and result.get('status') == 'success'

    def folder_uploadinfo(self, folder_id=None):
        """Get upload endpoint + token for direct uploads to a folder."""
        if not self.is_authorized():
            return {}
        params = {}
        if folder_id:
            params['id'] = folder_id
        status, result = _get(f"{self.BASE_URL}/folder/uploadinfo",
                              params=params, headers=self._auth_headers())
        if isinstance(result, dict) and result.get('status') == 'success':
            return result
        return {}

    # ------------------------------------------------------------------
    # ITEM MANAGEMENT
    # ------------------------------------------------------------------
    def item_details(self, item_id):
        if not self.is_authorized() or not item_id:
            return {}
        status, result = _get(f"{self.BASE_URL}/item/details",
                              params={'id': item_id},
                              headers=self._auth_headers())
        if isinstance(result, dict) and result.get('status') == 'success':
            return result
        return {}

    def item_rename(self, item_id, name):
        if not self.is_authorized() or not item_id or not name:
            return False
        status, result = _post(f"{self.BASE_URL}/item/rename",
                               data={'id': item_id, 'name': name},
                               headers=self._auth_headers())
        return isinstance(result, dict) and result.get('status') == 'success'

    def item_delete(self, item_id):
        if not self.is_authorized() or not item_id:
            return False
        status, result = _post(f"{self.BASE_URL}/item/delete",
                               data={'id': item_id},
                               headers=self._auth_headers())
        return isinstance(result, dict) and result.get('status') == 'success'

    def item_listall(self):
        """Recursive list of every file in the user's cloud."""
        if not self.is_authorized():
            return []
        status, result = _get(f"{self.BASE_URL}/item/listall",
                              headers=self._auth_headers())
        if isinstance(result, dict) and result.get('status') == 'success':
            return result.get('files', [])
        return []

    # ------------------------------------------------------------------
    # TRANSFERS
    # ------------------------------------------------------------------
    def transfer_create(self, src, folder_id=None):
        """Add a magnet / http URL / nzb URL as a transfer.

        Returns dict { id, name, type, status } on success, None on failure.
        """
        if not self.is_authorized() or not src:
            return None
        data = {'src': src}
        if folder_id:
            data['folder_id'] = folder_id
        status, result = _post(f"{self.BASE_URL}/transfer/create",
                               data=data, headers=self._auth_headers())
        if isinstance(result, dict) and result.get('status') == 'success':
            return result
        if isinstance(result, dict):
            xbmc.log(f"PM transfer/create failed: {result}", xbmc.LOGERROR)
        return None

    def transfer_list(self):
        if not self.is_authorized():
            return []
        status, result = _get(f"{self.BASE_URL}/transfer/list",
                              headers=self._auth_headers())
        if isinstance(result, dict) and result.get('status') == 'success':
            return result.get('transfers', [])
        return []

    def transfer_delete(self, transfer_id):
        if not self.is_authorized() or not transfer_id:
            return False
        status, result = _post(f"{self.BASE_URL}/transfer/delete",
                               data={'id': transfer_id},
                               headers=self._auth_headers())
        return isinstance(result, dict) and result.get('status') == 'success'

    def transfer_clearfinished(self):
        if not self.is_authorized():
            return False
        status, result = _post(f"{self.BASE_URL}/transfer/clearfinished",
                               data={}, headers=self._auth_headers())
        return isinstance(result, dict) and result.get('status') == 'success'

    def transfer_directdl(self, src):
        """Direct download - returns full content list (multi-file aware)."""
        if not self.is_authorized() or not src:
            return []
        status, result = _post(f"{self.BASE_URL}/transfer/directdl",
                               headers=self._auth_headers(),
                               data={"src": src})
        if isinstance(result, dict) and result.get('status') == 'success':
            return result.get('content', [])
        return []

    # ------------------------------------------------------------------
    # ZIP GENERATE
    # ------------------------------------------------------------------
    def zip_generate(self, item_ids=None, folder_ids=None):
        """Generate a ZIP archive containing items / folders.
        Returns the .zip URL on success.
        """
        if not self.is_authorized():
            return None
        from urllib.parse import urlencode as _ue
        body_parts = []
        for i in (item_ids or []):
            body_parts.append(('items[]', i))
        for f in (folder_ids or []):
            body_parts.append(('folders[]', f))
        if not body_parts:
            return None
        body = _ue(body_parts).encode('utf-8')
        status, result = _http(f"{self.BASE_URL}/zip/generate",
                               method='POST', data=body,
                               headers=self._auth_headers())
        if isinstance(result, dict) and result.get('status') == 'success':
            return result.get('location')
        return None

    # ------------------------------------------------------------------
    # SERVICES (supported hosters)
    # ------------------------------------------------------------------
    def services_list(self):
        """Return supported DDL hosters dict."""
        if not self.is_authorized():
            return {}
        status, result = _get(f"{self.BASE_URL}/services/list",
                              headers=self._auth_headers())
        if isinstance(result, dict) and result.get('status') == 'success':
            return result
        return {}


class _TorboxLinkDialog(xbmcgui.WindowDialog):
    """Custom Kodi dialog for linking TorBox via device-code + QR code.

    Everything (QR + instructions + code + buttons) is anchored to the LEFT
    side of the screen on a dimmed full-screen background.  While the dialog
    is open, the device-code endpoint is polled in a background thread; on
    success the dialog auto-closes and the parent flow saves the API key.

    A "Paste API Key" button is also provided as a manual fallback for users
    who would rather copy the key from torbox.app/settings directly.
    """

    _ACTION_PREVIOUS_MENU = 10
    _ACTION_NAV_BACK = 92

    def __init__(self, qr_path='', user_code='', friendly_url='',
                 verify_url='', device_code='', deadline=0, interval=5,
                 poll_fn=None):
        super().__init__()
        self.qr_path = qr_path
        self.user_code = user_code or ''
        self.friendly_url = friendly_url or ''
        self.verify_url = verify_url or ''
        self.device_code = device_code or ''
        self.deadline = float(deadline or 0)
        self.interval = max(2, int(interval or 5))
        self._poll_fn = poll_fn

        # Result fields
        self.api_key = ''
        self.action = 'cancel'   # 'success' | 'paste' | 'cancel' | 'expired' | 'error'
        self.error_message = ''

        self._stop = False
        self._poll_thread = None

        # ---- layout (Kodi 1280x720 working grid; auto-scaled by skin) ----
        x = 60
        col_w = 720

        # Bundled solid-color PNGs. ControlImage with an empty texture string
        # doesn't render on every Kodi build/skin (the colorDiffuse just tints
        # nothing), so we ship actual 8x8 solid PNGs and let Kodi stretch
        # them. This is what guarantees a solid black/white area behind the QR.
        _media = os.path.join(ADDON_PATH, 'resources', 'media')
        _black_png = os.path.join(_media, 'tb_black.png')
        _white_png = os.path.join(_media, 'tb_white.png')

        # Dim full-screen background (opaque so the underlying view doesn't
        # bleed through the dialog).
        self.addControl(xbmcgui.ControlImage(
            0, 0, 1280, 720, _black_png, colorDiffuse='FF0F1115'))

        # Left card (fully opaque so labels are always readable)
        self.addControl(xbmcgui.ControlImage(
            x - 24, 24, col_w + 48, 672, _black_png, colorDiffuse='FF1B2030'))

        # Title
        self.addControl(xbmcgui.ControlLabel(
            x, 46, col_w, 36,
            '[B]Link TorBox[/B]',
            font='font14', textColor='FFFFD54F'))

        self.addControl(xbmcgui.ControlLabel(
            x, 86, col_w, 28,
            'Scan the QR or visit the URL, then enter the code shown below.',
            font='font12', textColor='FFB0BEC5'))

        # QR (left column)
        qr_x, qr_y, qr_size = x, 130, 320
        # Solid BLACK backdrop behind the QR (uses a real PNG so it always
        # renders, even on skins that ignore empty-texture ControlImages).
        self.addControl(xbmcgui.ControlImage(
            qr_x - 20, qr_y - 20, qr_size + 40, qr_size + 40,
            _black_png))
        # Inner WHITE quiet-zone so QR scanners can lock onto the modules.
        self.addControl(xbmcgui.ControlImage(
            qr_x - 8, qr_y - 8, qr_size + 16, qr_size + 16,
            _white_png))
        if qr_path and os.path.exists(qr_path):
            self.qr_control = xbmcgui.ControlImage(
                qr_x, qr_y, qr_size, qr_size, qr_path)
        else:
            self.qr_control = xbmcgui.ControlLabel(
                qr_x, qr_y, qr_size, qr_size,
                '[B]QR unavailable[/B]\nOpen the URL on the right.',
                font='font12', textColor='FF263238',
                alignment=0x00000002 | 0x00000004)
        self.addControl(self.qr_control)

        # Instructions / code block (right of QR, still left half of screen)
        ix = x + qr_size + 30
        iw = col_w - qr_size - 30

        self.addControl(xbmcgui.ControlLabel(
            ix, qr_y, iw, 28,
            '[B]1.[/B] Scan QR or visit:',
            font='font13', textColor='FFFFFFFF'))

        self.addControl(xbmcgui.ControlLabel(
            ix, qr_y + 30, iw, 28,
            f'[COLOR FFFFD54F][B]{self.friendly_url}[/B][/COLOR]',
            font='font13'))

        self.addControl(xbmcgui.ControlLabel(
            ix, qr_y + 70, iw, 28,
            '[B]2.[/B] Enter this code:',
            font='font13', textColor='FFFFFFFF'))

        # Big user code
        self.code_lbl = xbmcgui.ControlLabel(
            ix, qr_y + 100, iw, 60,
            f'[COLOR FF81C784][B]{self.user_code}[/B][/COLOR]',
            font='font40')
        self.addControl(self.code_lbl)

        self.addControl(xbmcgui.ControlLabel(
            ix, qr_y + 170, iw, 28,
            '[B]3.[/B] Sign in to authorize.',
            font='font13', textColor='FFFFFFFF'))

        # Status (countdown / polling state)
        self.status_lbl = xbmcgui.ControlLabel(
            ix, qr_y + 210, iw, 60,
            'Waiting for authorization...',
            font='font12', textColor='FFB0BEC5')
        self.addControl(self.status_lbl)

        # ---- buttons (left side) ----
        btn_y = qr_y + qr_size + 30
        btn_h = 50

        self.btn_paste = xbmcgui.ControlButton(
            x, btn_y, 300, btn_h,
            'Paste API Key',
            font='font13', textColor='FFECEFF1',
            focusedColor='FFFFFFFF',
            alignment=0x00000002 | 0x00000004)
        self.addControl(self.btn_paste)

        self.btn_cancel = xbmcgui.ControlButton(
            x + 320, btn_y, 200, btn_h,
            'Cancel',
            font='font13', textColor='FFECEFF1',
            focusedColor='FFFFFFFF',
            alignment=0x00000002 | 0x00000004)
        self.addControl(self.btn_cancel)

        self.btn_paste.controlRight(self.btn_cancel)
        self.btn_cancel.controlLeft(self.btn_paste)
        self.setFocus(self.btn_paste)

        # Start background polling for device-code completion
        if self.device_code and self._poll_fn and self.deadline > time.time():
            try:
                import threading
                self._poll_thread = threading.Thread(
                    target=self._poll_loop, daemon=True)
                self._poll_thread.start()
            except Exception as e:
                xbmc.log(f'Torbox poll thread start failed: {e}',
                         xbmc.LOGWARNING)

    # ----- background polling ----------------------------------------------
    def _poll_loop(self):
        try:
            while not self._stop:
                now = time.time()
                remaining = int(self.deadline - now)
                if remaining <= 0:
                    self.action = 'expired'
                    self._safe_update_status('Code expired - please retry.')
                    self._safe_close()
                    return

                mins, secs = divmod(remaining, 60)
                self._safe_update_status(
                    f'Waiting for authorization...  '
                    f'expires in {mins:02d}:{secs:02d}')

                api_key, err = self._poll_fn(self.device_code)
                if self._stop:
                    return

                if api_key:
                    self.api_key = api_key
                    self.action = 'success'
                    self._safe_update_status('Authorized! Saving...')
                    self._safe_close()
                    return

                if err and err not in ('pending', 'slow_down'):
                    self.action = 'error'
                    self.error_message = err
                    self._safe_update_status(f'Error: {err}')
                    self._safe_close()
                    return

                if err == 'slow_down':
                    self.interval = min(30, self.interval + 5)

                # Sleep in chunks so cancel is responsive
                slept = 0
                while not self._stop and slept < self.interval * 1000:
                    xbmc.sleep(250)
                    slept += 250
        except Exception as e:
            xbmc.log(f'Torbox poll loop error: {e}', xbmc.LOGERROR)
            self.action = 'error'
            self.error_message = str(e)
            self._safe_close()

    def _safe_update_status(self, text):
        try:
            self.status_lbl.setLabel(text)
        except Exception:
            pass

    def _safe_close(self):
        try:
            self.close()
        except Exception:
            pass

    # ----- event handlers --------------------------------------------------
    def onControl(self, control):
        try:
            if control == self.btn_paste:
                self._do_paste()
            elif control == self.btn_cancel:
                self.action = 'cancel'
                self._stop = True
                self.close()
        except Exception as e:
            xbmc.log(f'Torbox dialog onControl error: {e}', xbmc.LOGERROR)

    def onAction(self, action):
        try:
            aid = action.getId()
            if aid in (self._ACTION_PREVIOUS_MENU, self._ACTION_NAV_BACK):
                self.action = 'cancel'
                self._stop = True
                self.close()
        except Exception:
            pass

    def _do_paste(self):
        kb = xbmc.Keyboard('', 'Paste TorBox API Key')
        kb.doModal()
        if not kb.isConfirmed():
            return
        key = (kb.getText() or '').strip()
        if not key:
            xbmcgui.Dialog().notification(
                'TorBox', 'No API key entered',
                xbmcgui.NOTIFICATION_WARNING)
            return
        self.api_key = key
        self.action = 'paste'
        self._stop = True
        self.close()




class Torbox:
    """Torbox API integration - API key auth.

    Mirrors the workflow used by the original community implementation:
      * manual API key entry (TorBox issues a long-lived API key per account)
      * /torrents/createtorrent  to add a magnet
      * /torrents/checkcached    to check cache (POST hashes, format=list)
      * /torrents/requestdl      to obtain a direct download URL
      * /torrents/mylist         to list cloud torrents / file metadata
      * /usenet/*                parallel surface for Usenet downloads
    """

    BASE_URL = "https://api.torbox.app/v1/api"
    API_KEY_PAGE = "https://torbox.app/settings"
    USER_AGENT = "Genesis"

    # --- generic helpers --------------------------------------------------
    def __init__(self):
        self._load_from_file()

    def _load_from_file(self):
        _ensure_data_path()
        self.token = ''
        if os.path.exists(TB_TOKEN_FILE):
            try:
                with open(TB_TOKEN_FILE, 'r') as f:
                    data = json.load(f)
                    self.token = data.get('access_token', '') or data.get('api_key', '')
                    if self.token:
                        xbmc.log('Torbox: Loaded API key from file', xbmc.LOGDEBUG)
            except Exception:
                pass
        if not self.token:
            self.token = get_addon().getSetting('tb_api_key') or ''

    def _save_to_file(self):
        _ensure_data_path()
        try:
            with open(TB_TOKEN_FILE, 'w') as f:
                json.dump({'access_token': self.token, 'api_key': self.token,
                           'created_at': time.time()}, f)
            addon = get_addon()
            addon.setSetting('tb_api_key', self.token)
            addon.setSetting('tb_auth_done', 'true')
        except Exception:
            pass

    def _auth_headers(self):
        return {'Authorization': f'Bearer {self.token}'}

    def is_authorized(self):
        return bool(self.token)

    # --- video filter helpers (inlined to avoid extra dependencies) -------
    @staticmethod
    def _video_extensions():
        return ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm',
                '.flv', '.mpeg', '.mpg', '.ts', '.m2ts', '.iso')

    @staticmethod
    def _extras_terms():
        return ('sample', 'trailer', 'rarbg', 'extras', 'featurette',
                'deleted.scene', 'behind.the.scenes', 'making.of', 'bonus')

    @staticmethod
    def _seas_ep_filter(season, episode, name):
        try:
            s = int(season)
            e = int(episode)
        except Exception:
            return True
        n = name.lower()
        patterns = (
            f's{s:02d}e{e:02d}', f's{s}e{e}', f's{s:02d}.e{e:02d}',
            f'{s}x{e:02d}', f'{s}x{e}', f'season {s} episode {e}',
            f'season.{s}.episode.{e}',
        )
        return any(p in n for p in patterns)

    def _m2ts_check(self, files):
        for it in files:
            n = it.get('filename') or it.get('short_name') or ''
            if n.lower().endswith('.m2ts'):
                return True
        return False

    # --- authorization ----------------------------------------------------
    # TorBox device-code OAuth flow (verified working):
    #   GET  /v1/api/user/auth/device/start?app=Genesis
    #   POST /v1/api/user/auth/device/token  (body: {"device_code": "..."})
    TB_SETTINGS_URL = 'https://torbox.app/settings/api'

    def authorize(self):
        """Let the user pick how to link TorBox: device-code (QR) or manual key."""
        try:
            dialog = xbmcgui.Dialog()
            choice = dialog.select(
                'Link TorBox',
                ['Get Code (scan QR / visit tor.box/link)',
                 'Enter API Key manually'],
            )
            if choice == 0:
                return self.authorize_device()
            if choice == 1:
                return self.authorize_api_key()
            return False
        except Exception as e:
            xbmc.log(f'Torbox auth error: {e}', xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Error', f'Auth failed: {e}',
                                          xbmcgui.NOTIFICATION_ERROR)
            return False

    def authorize_api_key(self):
        """Manual API key entry. The user pastes the key from torbox.app/settings."""
        try:
            dialog = xbmcgui.Dialog()
            api_key = dialog.input(
                'TorBox API Key (paste from torbox.app/settings)')
            if not api_key:
                return False
            api_key = api_key.strip()
            self.token = api_key
            info = self.account_info_raw()
            if info and info.get('success'):
                self._save_to_file()
                dialog.notification('Success', 'TorBox linked!',
                                    xbmcgui.NOTIFICATION_INFO)
                xbmc.log('Torbox: API key validated and saved', xbmc.LOGINFO)
                return True
            self.token = ''
            dialog.notification('TorBox', 'Invalid API key',
                                xbmcgui.NOTIFICATION_ERROR)
            return False
        except Exception as e:
            xbmc.log(f'Torbox API key auth error: {e}', xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Error', f'Auth failed: {e}',
                                          xbmcgui.NOTIFICATION_ERROR)
            return False

    def _ensure_qr_image(self, url):
        """Generate a QR code PNG for `url` and return its local path.

        Uses api.qrserver.com so we don't need any extra Python deps in Kodi.
        Cached in the addon's profile directory.
        """
        _ensure_data_path()
        try:
            from urllib.parse import quote
            qr_path = os.path.join(ADDON_DATA_PATH, 'tb_link_qr.png')
            qr_url = (
                'https://api.qrserver.com/v1/create-qr-code/'
                f'?size=480x480&margin=12&qzone=2&format=png'
                f'&bgcolor=ffffff&color=000000&data={quote(url, safe="")}'
            )
            req = Request(qr_url, headers={'User-Agent': USER_AGENT})
            with urlopen(req, timeout=20) as resp:
                data = resp.read()
            if data and len(data) > 200:
                with open(qr_path, 'wb') as f:
                    f.write(data)
                return qr_path
        except Exception as e:
            xbmc.log(f'Torbox QR generation failed: {e}', xbmc.LOGWARNING)
        return ''

    def _poll_device_token(self, device_code):
        """One poll of /user/auth/device/token. Returns (api_key, error)."""
        try:
            _, poll = _post(
                f'{self.BASE_URL}/user/auth/device/token',
                data=json.dumps({'device_code': device_code}),
                headers={'Content-Type': 'application/json'},
            )
        except Exception as e:
            return '', f'Network error: {e}'

        if not isinstance(poll, dict):
            return '', 'Network error'

        if poll.get('success'):
            pdata = poll.get('data')
            api_key = ''
            if isinstance(pdata, str):
                api_key = pdata
            elif isinstance(pdata, dict):
                api_key = (pdata.get('api_key')
                           or pdata.get('token')
                           or pdata.get('access_token')
                           or pdata.get('apikey')
                           or '')
            return (api_key or '').strip(), ''

        err = poll.get('error') or ''
        # Pending states (keep polling)
        if err in ('DEVICE_CODE_NOT_USED', 'AUTHORIZATION_PENDING',
                   'SLOW_DOWN', 'PENDING', ''):
            return '', 'pending' if err != 'SLOW_DOWN' else 'slow_down'
        # Terminal failure
        return '', err or 'Authorization failed'

    def authorize_device(self):
        """Device-code (Get Code) flow with a left-anchored QR dialog.

        Steps:
          1. Call /user/auth/device/start to get device_code + short user code
             + verification_url.
          2. Open a custom WindowDialog with the QR (encoding the verification
             URL) and instructions/code/buttons pinned to the LEFT side of
             the screen.
          3. The dialog polls /user/auth/device/token in the background until
             the user authorises on the website, or pastes the API key
             manually via the "Paste API Key" button, or cancels / times out.
        """
        dialog = xbmcgui.Dialog()
        try:
            _, result = _get(
                f'{self.BASE_URL}/user/auth/device/start',
                params={'app': 'Genesis'},
            )
            if not isinstance(result, dict) or not result.get('success'):
                detail = (result or {}).get('detail') if isinstance(result, dict) \
                    else 'Network error'
                dialog.notification('TorBox', f'Cannot start: {detail}',
                                    xbmcgui.NOTIFICATION_ERROR)
                return False

            data = result.get('data') or {}
            device_code = data.get('device_code') or ''
            user_code = data.get('code') or ''
            verify_url = (data.get('verification_url')
                          or 'https://torbox.app/oauth/device')
            friendly_url = (data.get('friendly_verification_url')
                            or 'https://tor.box/link')
            interval = max(2, int(data.get('interval', 5) or 5))

            # Deadline from expires_at (fallback: 10 minutes)
            deadline = time.time() + 600
            expires_at = data.get('expires_at') or ''
            if expires_at:
                try:
                    from datetime import datetime
                    exp_dt = datetime.strptime(str(expires_at)[:19],
                                               '%Y-%m-%dT%H:%M:%S')
                    # expires_at is UTC ('Z'). Convert to epoch seconds.
                    import calendar
                    deadline = calendar.timegm(exp_dt.timetuple())
                except Exception:
                    pass

            if not device_code or not user_code:
                dialog.notification('TorBox', 'Malformed device auth response',
                                    xbmcgui.NOTIFICATION_ERROR)
                return False

            # Build QR for the verification URL so scanning lands the user
            # right on the authorize page.
            qr_path = self._ensure_qr_image(verify_url)

            link_win = _TorboxLinkDialog(
                qr_path=qr_path,
                user_code=user_code,
                friendly_url=friendly_url,
                verify_url=verify_url,
                device_code=device_code,
                deadline=deadline,
                interval=interval,
                poll_fn=self._poll_device_token,
            )
            link_win.doModal()
            action = link_win.action
            api_key = (link_win.api_key or '').strip()
            err_msg = link_win.error_message or ''
            del link_win

            if action == 'cancel':
                return False
            if action == 'expired':
                dialog.notification('TorBox', 'Code expired',
                                    xbmcgui.NOTIFICATION_ERROR)
                return False
            if action == 'error':
                dialog.notification('TorBox',
                                    err_msg or 'Authorization failed',
                                    xbmcgui.NOTIFICATION_ERROR)
                return False
            if not api_key:
                return False

            # Validate against /user/me before saving
            self.token = api_key
            info = self.account_info_raw()
            if info and info.get('success'):
                self._save_to_file()
                dialog.notification('Success', 'TorBox linked!',
                                    xbmcgui.NOTIFICATION_INFO)
                xbmc.log('Torbox: device-code/QR auth success', xbmc.LOGINFO)
                return True

            self.token = ''
            detail = ''
            if isinstance(info, dict):
                detail = info.get('detail') or info.get('error') or ''
            dialog.notification('TorBox',
                                f'Key validation failed{": " + detail if detail else ""}',
                                xbmcgui.NOTIFICATION_ERROR)
            return False
        except Exception as e:
            xbmc.log(f'Torbox device auth error: {e}', xbmc.LOGERROR)
            dialog.notification('Error', f'Auth failed: {e}',
                                xbmcgui.NOTIFICATION_ERROR)
            return False

    def revoke(self):
        if os.path.exists(TB_TOKEN_FILE):
            try:
                os.remove(TB_TOKEN_FILE)
            except Exception:
                pass
        addon = get_addon()
        addon.setSetting('tb_api_key', '')
        addon.setSetting('tb_auth_done', 'false')
        self.token = ''
        xbmcgui.Dialog().notification('Torbox', 'Account unlinked',
                                      xbmcgui.NOTIFICATION_INFO)

    # --- low-level API ----------------------------------------------------
    def account_info_raw(self):
        if not self.token:
            return None
        status, result = _get(f'{self.BASE_URL}/user/me',
                              headers=self._auth_headers())
        return result if isinstance(result, dict) else None

    def _add_magnet(self, magnet):
        """POST /torrents/createtorrent as multipart-style form data
        with seed=3, allow_zip=False (matches the public TorBox spec)."""
        if not self.is_authorized():
            return None
        status, result = _post(
            f'{self.BASE_URL}/torrents/createtorrent',
            data={'magnet': magnet, 'seed': '3', 'allow_zip': 'false'},
            headers=self._auth_headers(),
        )
        return result if isinstance(result, dict) else None

    def torrent_info(self, request_id):
        status, result = _get(
            f'{self.BASE_URL}/torrents/mylist',
            params={'id': request_id, 'bypass_cache': 'true'},
            headers=self._auth_headers(),
        )
        return result if isinstance(result, dict) else None

    def delete_torrent(self, request_id):
        return _post(
            f'{self.BASE_URL}/torrents/controltorrent',
            data=json.dumps({'torrent_id': request_id, 'operation': 'delete'}),
            headers={**self._auth_headers(), 'Content-Type': 'application/json'},
        )

    def delete_usenet(self, request_id):
        return _post(
            f'{self.BASE_URL}/usenet/controlusenetdownload',
            data=json.dumps({'usenet_id': request_id, 'operation': 'delete'}),
            headers={**self._auth_headers(), 'Content-Type': 'application/json'},
        )

    # --- cache check ------------------------------------------------------
    def check_cache(self, hashes):
        """POST /torrents/checkcached with {hashes:[...]} and ?format=list"""
        if not self.is_authorized() or not hashes:
            return {}
        try:
            status, result = _post(
                f'{self.BASE_URL}/torrents/checkcached',
                params={'format': 'list'},
                data=json.dumps({'hashes': hashes[:100]}),
                headers={**self._auth_headers(), 'Content-Type': 'application/json'},
            )
            if isinstance(result, dict) and result.get('success'):
                data = result.get('data') or {}
                cached = {}
                # data may be a dict keyed by hash or a list of dicts
                if isinstance(data, list):
                    for it in data:
                        h = (it.get('hash') or '').lower()
                        if h:
                            cached[h] = True
                elif isinstance(data, dict):
                    for h, v in data.items():
                        if v:
                            cached[h.lower()] = True
                return cached
        except Exception as e:
            xbmc.log(f'Torbox cache check error: {e}', xbmc.LOGERROR)
        return {}

    # --- link resolution --------------------------------------------------
    def unrestrict_link(self, file_id):
        """file_id is the combined "torrent_id,file_id" string."""
        if not self.is_authorized():
            return None
        try:
            torrent_id, fid = str(file_id).split(',')
            status, result = _get(
                f'{self.BASE_URL}/torrents/requestdl',
                params={'token': self.token, 'torrent_id': torrent_id, 'file_id': fid},
                headers=self._auth_headers(),
            )
            if isinstance(result, dict) and result.get('success'):
                return result.get('data')
        except Exception as e:
            xbmc.log(f'Torbox unrestrict error: {e}', xbmc.LOGERROR)
        return None

    def unrestrict_usenet(self, file_id):
        if not self.is_authorized():
            return None
        try:
            usenet_id, fid = str(file_id).split(',')
            status, result = _get(
                f'{self.BASE_URL}/usenet/requestdl',
                params={'token': self.token, 'usenet_id': usenet_id,
                        'file_id': fid, 'user_ip': 'true'},
                headers=self._auth_headers(),
            )
            if isinstance(result, dict) and result.get('success'):
                return result.get('data')
        except Exception as e:
            xbmc.log(f'Torbox usenet unrestrict error: {e}', xbmc.LOGERROR)
        return None

    def resolve_magnet(self, magnet, info_hash='', store_to_cloud=False,
                       title='', season='', episode=''):
        """Smart magnet resolver with file-selection + season/episode filter."""
        torrent_id = None
        try:
            extensions = self._video_extensions()
            extras_terms = self._extras_terms()
            extras_filter = tuple(t for t in extras_terms if t not in (title or '').lower())
            response = self._add_magnet(magnet)
            if not response or not response.get('success'):
                return None
            data = response.get('data') or {}
            torrent_id = data.get('torrent_id') or data.get('id')
            if not torrent_id:
                return None

            # Wait briefly for files to appear
            files = []
            for _ in range(15):
                info = self.torrent_info(torrent_id)
                if isinstance(info, dict) and info.get('success'):
                    tdata = info.get('data') or {}
                    if isinstance(tdata, list) and tdata:
                        tdata = tdata[0]
                    files = tdata.get('files') or []
                    if files:
                        break
                time.sleep(2)

            selected = []
            for f in files:
                name = f.get('short_name') or f.get('name') or ''
                if name.lower().endswith(extensions):
                    selected.append({
                        'url': f"{torrent_id},{f.get('id', 0)}",
                        'filename': name,
                        'size': int(f.get('size', 0) or 0),
                    })
            if not selected:
                return None

            if season:
                selected = [s for s in selected
                            if self._seas_ep_filter(season, episode, s['filename'])]
            else:
                if self._m2ts_check([{'filename': s['filename']} for s in selected]):
                    return None
                selected = [s for s in selected
                            if not any(x in s['filename'].lower() for x in extras_filter)]
                selected.sort(key=lambda k: k['size'], reverse=True)

            if not selected:
                return None
            url = self.unrestrict_link(selected[0]['url'])
            if not store_to_cloud and torrent_id:
                try:
                    self.delete_torrent(torrent_id)
                except Exception:
                    pass
            return url
        except Exception as e:
            xbmc.log(f'Torbox resolve_magnet error: {e}', xbmc.LOGERROR)
            if torrent_id:
                try:
                    self.delete_torrent(torrent_id)
                except Exception:
                    pass
            return None

    def display_magnet_pack(self, magnet, info_hash=''):
        """List all video files inside a magnet without playing anything."""
        torrent_id = None
        try:
            response = self._add_magnet(magnet)
            if not response or not response.get('success'):
                return None
            data = response.get('data') or {}
            torrent_id = data.get('torrent_id') or data.get('id')
            if not torrent_id:
                return None

            files = []
            for _ in range(15):
                info = self.torrent_info(torrent_id)
                if isinstance(info, dict) and info.get('success'):
                    tdata = info.get('data') or {}
                    if isinstance(tdata, list) and tdata:
                        tdata = tdata[0]
                    files = tdata.get('files') or []
                    if files:
                        break
                time.sleep(2)

            extensions = self._video_extensions()
            out = []
            for f in files:
                name = f.get('short_name') or f.get('name') or ''
                if name.lower().endswith(extensions):
                    out.append({
                        'link': f"{torrent_id},{f.get('id', 0)}",
                        'filename': name,
                        'size': int(f.get('size', 0) or 0),
                    })
            try:
                self.delete_torrent(torrent_id)
            except Exception:
                pass
            return out or None
        except Exception as e:
            xbmc.log(f'Torbox display_magnet_pack error: {e}', xbmc.LOGERROR)
            if torrent_id:
                try:
                    self.delete_torrent(torrent_id)
                except Exception:
                    pass
            return None

    # Backwards-compat: existing code calls add_magnet to play a single magnet
    def add_magnet(self, magnet, check_cache_first=True):
        return self.resolve_magnet(magnet, store_to_cloud=False)

    # --- cloud listings ---------------------------------------------------
    def user_cloud(self):
        status, result = _get(f'{self.BASE_URL}/torrents/mylist',
                              headers=self._auth_headers())
        return result if isinstance(result, dict) else {}

    def user_cloud_usenet(self):
        status, result = _get(f'{self.BASE_URL}/usenet/mylist',
                              headers=self._auth_headers())
        return result if isinstance(result, dict) else {}

    def user_cloud_info(self, request_id):
        status, result = _get(
            f'{self.BASE_URL}/torrents/mylist',
            params={'id': request_id},
            headers=self._auth_headers(),
        )
        return result if isinstance(result, dict) else {}

    def user_cloud_info_usenet(self, request_id):
        status, result = _get(
            f'{self.BASE_URL}/usenet/mylist',
            params={'id': request_id},
            headers=self._auth_headers(),
        )
        return result if isinstance(result, dict) else {}

    # --- account info -----------------------------------------------------
    def account_info(self):
        if not self.token:
            return {}
        try:
            result = self.account_info_raw()
            if not isinstance(result, dict) or not result.get('success'):
                return {'type': 'expired', 'premium': False, 'days_left': 0,
                        'expiration': 'API key invalid - re-authorize'}
            data = result.get('data') or {}
            plans = {0: 'Free', 1: 'Essential', 2: 'Pro', 3: 'Standard'}
            plan_id = data.get('plan', 0) or 0
            premium_until = (data.get('premium_expires_at')
                             or data.get('plan_active_until') or '')
            days_left = 0
            exp_str = 'Unknown'
            if premium_until:
                try:
                    from datetime import datetime
                    exp_date = datetime.strptime(str(premium_until)[:19],
                                                 '%Y-%m-%dT%H:%M:%S')
                    delta = exp_date - datetime.utcnow()
                    days_left = max(0, delta.days)
                    exp_str = exp_date.strftime('%Y-%m-%d')
                except Exception:
                    exp_str = str(premium_until)[:10]
            return {
                'username': data.get('email', ''),
                'email': data.get('email', ''),
                'type': 'premium' if plan_id else 'free',
                'plan': plans.get(plan_id, str(plan_id)),
                'premium': bool(plan_id),
                'expiration': exp_str,
                'days_left': days_left,
                'total_downloaded': data.get('total_downloaded', 0),
                'customer': data.get('customer', ''),
            }
        except Exception as e:
            xbmc.log(f'TB account_info error: {e}', xbmc.LOGERROR)
        return {}


class LinkSnappy:
    """LinkSnappy debrid service - API key auth"""
    BASE_URL = 'https://linksnappy.com/api'

    def __init__(self):
        self.username = ''
        self.password = ''
        self.cookie = ''
        self._load_credentials()

    def _load_credentials(self):
        addon = get_addon()
        self.username = addon.getSetting('ls_username') or ''
        self.password = addon.getSetting('ls_password') or ''
        self.cookie = addon.getSetting('ls_cookie') or ''
        if not self.cookie and os.path.exists(LS_TOKEN_FILE):
            try:
                with open(LS_TOKEN_FILE, 'r') as f:
                    data = json.load(f)
                    self.cookie = data.get('cookie', '')
                    self.username = data.get('username', self.username)
            except:
                pass

    def _save_credentials(self, cookie):
        self.cookie = cookie
        addon = get_addon()
        addon.setSetting('ls_cookie', cookie)
        addon.setSetting('ls_auth_done', 'true')
        try:
            os.makedirs(os.path.dirname(LS_TOKEN_FILE), exist_ok=True)
            with open(LS_TOKEN_FILE, 'w') as f:
                json.dump({'cookie': cookie, 'username': self.username}, f)
        except:
            pass

    def authorize(self):
        """LinkSnappy login auth"""
        try:
            dialog = xbmcgui.Dialog()
            username = dialog.input('LinkSnappy Username')
            if not username:
                return
            password = dialog.input('LinkSnappy Password', option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if not password:
                return

            xbmc.log('LinkSnappy: Logging in...', xbmc.LOGINFO)

            import urllib.request
            import urllib.parse
            import http.cookiejar

            cj = http.cookiejar.CookieJar()
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
            data = urllib.parse.urlencode({
                'username': username,
                'password': password
            }).encode()
            req = urllib.request.Request(f'{self.BASE_URL}/AUTHENTICATE',
                                         data=data,
                                         headers={'User-Agent': 'Genesis/2.3.0'})
            resp = opener.open(req, timeout=15)
            result = json.loads(resp.read().decode())

            if result.get('status') == 'OK':
                # Extract cookie string
                cookies = '; '.join([f'{c.name}={c.value}' for c in cj])
                self.username = username
                self.password = password
                addon = get_addon()
                addon.setSetting('ls_username', username)
                addon.setSetting('ls_password', password)
                self._save_credentials(cookies)
                dialog.notification('LinkSnappy', f'Logged in as {username}', xbmcgui.NOTIFICATION_INFO)
            else:
                error_msg = result.get('error', 'Login failed')
                dialog.notification('LinkSnappy', error_msg, xbmcgui.NOTIFICATION_ERROR)
                xbmc.log(f'LinkSnappy login error: {error_msg}', xbmc.LOGERROR)

        except Exception as e:
            xbmc.log(f'LinkSnappy auth error: {e}', xbmc.LOGERROR)
            xbmcgui.Dialog().notification('LinkSnappy', f'Auth error: {e}', xbmcgui.NOTIFICATION_ERROR)

    def is_authorized(self):
        if self.username and self.password:
            return True
        if self.cookie:
            return True
        return False

    def _login_headers(self):
        headers = {'User-Agent': 'Genesis/2.3.0'}
        if self.cookie:
            headers['Cookie'] = self.cookie
        return headers

    def unrestrict_link(self, link):
        """Generate a premium download link"""
        if not self.is_authorized():
            return None
        try:
            import urllib.request
            import urllib.parse

            # Re-login if needed
            if not self.cookie and self.username and self.password:
                self._re_login()

            data = urllib.parse.urlencode({
                'genLinks': json.dumps([{'link': link}]),
                'username': self.username,
                'password': self.password,
            }).encode()

            req = urllib.request.Request(f'{self.BASE_URL}/linkgen',
                                         data=data,
                                         headers=self._login_headers())
            resp = urllib.request.urlopen(req, timeout=30)
            result = json.loads(resp.read().decode())

            if result.get('status') == 'OK':
                links = result.get('links', [])
                if links:
                    gen = links[0].get('generated', '')
                    if gen:
                        return gen
            elif result.get('status') == 'ERROR':
                xbmc.log(f'LinkSnappy linkgen error: {result.get("error", "")}', xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f'LinkSnappy unrestrict error: {e}', xbmc.LOGERROR)
        return None

    def _re_login(self):
        """Re-authenticate to get fresh cookies"""
        try:
            import urllib.request
            import urllib.parse
            import http.cookiejar

            cj = http.cookiejar.CookieJar()
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
            data = urllib.parse.urlencode({
                'username': self.username,
                'password': self.password
            }).encode()
            req = urllib.request.Request(f'{self.BASE_URL}/AUTHENTICATE',
                                         data=data,
                                         headers={'User-Agent': 'Genesis/2.3.0'})
            resp = opener.open(req, timeout=15)
            result = json.loads(resp.read().decode())
            if result.get('status') == 'OK':
                cookies = '; '.join([f'{c.name}={c.value}' for c in cj])
                self._save_credentials(cookies)
        except:
            pass

    def add_magnet(self, magnet, check_cache_first=True):
        return self.unrestrict_link(magnet)

    def check_cache(self, hashes):
        return {}

    def revoke(self):
        if os.path.exists(LS_TOKEN_FILE):
            try:
                os.remove(LS_TOKEN_FILE)
            except:
                pass
        addon = get_addon()
        addon.setSetting('ls_username', '')
        addon.setSetting('ls_password', '')
        addon.setSetting('ls_cookie', '')
        addon.setSetting('ls_auth_done', 'false')
        self.username = ''
        self.password = ''
        self.cookie = ''
        xbmcgui.Dialog().notification('LinkSnappy', 'Account unlinked', xbmcgui.NOTIFICATION_INFO)

    def account_info(self):
        """Get LinkSnappy account info"""
        if not self.is_authorized():
            return {}
        try:
            import urllib.request
            import urllib.parse

            if not self.cookie and self.username and self.password:
                self._re_login()

            data = urllib.parse.urlencode({
                'username': self.username,
                'password': self.password,
            }).encode()
            req = urllib.request.Request(f'{self.BASE_URL}/USERDETAILS',
                                         data=data,
                                         headers=self._login_headers())
            resp = urllib.request.urlopen(req, timeout=15)
            result = json.loads(resp.read().decode())

            if result.get('status') == 'OK':
                user_data = result.get('return', {})
                expire = user_data.get('expire', '')
                days_left = 0
                exp_str = 'Unknown'
                if expire:
                    try:
                        from datetime import datetime
                        if str(expire).isdigit():
                            exp_date = datetime.utcfromtimestamp(int(expire))
                        else:
                            exp_date = datetime.strptime(str(expire)[:19], '%Y-%m-%dT%H:%M:%S')
                        delta = exp_date - datetime.utcnow()
                        days_left = max(0, delta.days)
                        exp_str = exp_date.strftime('%Y-%m-%d')
                    except:
                        exp_str = str(expire)
                return {
                    'username': self.username,
                    'type': user_data.get('package', 'unknown'),
                    'premium': bool(days_left > 0),
                    'expiration': exp_str,
                    'days_left': days_left,
                }
        except Exception as e:
            xbmc.log(f'LS account_info error: {e}', xbmc.LOGERROR)
        return {}


def get_debrid_services():
    """Get list of authorized debrid services in priority order"""
    services = []
    
    rd = RealDebrid()
    if rd.is_authorized():
        services.append(('Real-Debrid', rd))
        xbmc.log('Debrid: Real-Debrid is authorized', xbmc.LOGINFO)
    
    ad = AllDebrid()
    if ad.is_authorized():
        services.append(('AllDebrid', ad))
        xbmc.log('Debrid: AllDebrid is authorized', xbmc.LOGINFO)
    
    pm = Premiumize()
    if pm.is_authorized():
        services.append(('Premiumize', pm))
        xbmc.log('Debrid: Premiumize is authorized', xbmc.LOGINFO)
    
    tb = Torbox()
    if tb.is_authorized():
        services.append(('Torbox', tb))
        xbmc.log('Debrid: Torbox is authorized', xbmc.LOGINFO)
    
    ls = LinkSnappy()
    if ls.is_authorized():
        services.append(('LinkSnappy', ls))
        xbmc.log('Debrid: LinkSnappy is authorized', xbmc.LOGINFO)
    
    if not services:
        xbmc.log('Debrid: No debrid services authorized', xbmc.LOGWARNING)
    
    return services


def resolve_with_debrid(link_or_magnet, is_magnet=False):
    """Try to resolve link through available debrid services.

    Services that quick-probe and return None typically mean "not cached".
    We move on to the next service immediately rather than hanging the user.
    """
    services = get_debrid_services()

    for name, service in services:
        try:
            xbmc.log(f"Attempting to resolve via {name}...", xbmc.LOGINFO)
            if is_magnet:
                result = service.add_magnet(link_or_magnet, check_cache_first=True)
            else:
                result = service.unrestrict_link(link_or_magnet)
            if result:
                xbmc.log(f"Resolved via {name}: {str(result)[:80]}...", xbmc.LOGINFO)
                return result, name
            else:
                xbmc.log(f"{name}: no playable link (source likely uncached). Trying next service.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"{name} failed: {str(e)}", xbmc.LOGERROR)
            continue

    return None, None


# ── Compatibility aliases for player.py ──────────────────────────────────

def get_active_services():
    """Alias for get_debrid_services() - returns list of (name, service) tuples."""
    return get_debrid_services()


def check_cache_all(hashes):
    """Check all hashes against all authorized debrid services in parallel.

    Returns a set of cached info hashes (lowercase). Per-service timeouts keep
    a slow API from blocking the whole UI.
    """
    cached = set()
    services = get_debrid_services()
    if not services or not hashes:
        return cached

    import concurrent.futures

    def _check(name, service):
        try:
            if not hasattr(service, 'check_cache'):
                return set()
            result = service.check_cache(hashes)
            local = set()
            if isinstance(result, (set, list)):
                for h in result:
                    local.add(str(h).lower())
            elif isinstance(result, dict):
                for h, is_cached in result.items():
                    if is_cached:
                        local.add(str(h).lower())
            return local
        except Exception as e:
            xbmc.log(f'Cache check failed for {name}: {e}', xbmc.LOGDEBUG)
            return set()

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(2, len(services))) as pool:
        futures = {pool.submit(_check, name, svc): name for name, svc in services}
        for fut in concurrent.futures.as_completed(futures, timeout=15):
            try:
                cached.update(fut.result(timeout=10))
            except Exception as e:
                xbmc.log(f'Cache check future error: {e}', xbmc.LOGDEBUG)

    return cached


def resolve_magnet(magnet):
    """Resolve a magnet link through debrid. Returns (url, service_name) or (None, None)."""
    return resolve_with_debrid(magnet, is_magnet=True)


def get_all_account_info():
    """Get account status for all debrid services."""
    accounts = []
    
    # Real-Debrid
    try:
        rd = RealDebrid()
        if rd.token:
            info = rd.account_info()
            if info:
                accounts.append({
                    'name': 'Real-Debrid',
                    'configured': True,
                    'username': info.get('username', ''),
                    'email': info.get('email', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                    'points': info.get('points', 0),
                })
            else:
                accounts.append({'name': 'Real-Debrid', 'configured': True, 
                                 'error': 'Could not fetch account info - try re-authorizing'})
        else:
            accounts.append({'name': 'Real-Debrid', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'Real-Debrid', 'configured': True, 'error': str(e)})
    
    # AllDebrid
    try:
        ad = AllDebrid()
        if ad.token:
            info = ad.account_info()
            if info:
                accounts.append({
                    'name': 'AllDebrid',
                    'configured': True,
                    'username': info.get('username', ''),
                    'email': info.get('email', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                })
            else:
                accounts.append({'name': 'AllDebrid', 'configured': True,
                                 'error': 'Could not fetch account info - try re-authorizing'})
        else:
            accounts.append({'name': 'AllDebrid', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'AllDebrid', 'configured': True, 'error': str(e)})
    
    # Premiumize
    try:
        pm = Premiumize()
        if pm.token:
            info = pm.account_info()
            if info:
                accounts.append({
                    'name': 'Premiumize',
                    'configured': True,
                    'username': info.get('username', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                })
            else:
                accounts.append({'name': 'Premiumize', 'configured': True,
                                 'error': 'Could not fetch account info - try re-authorizing'})
        else:
            accounts.append({'name': 'Premiumize', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'Premiumize', 'configured': True, 'error': str(e)})
    
    # Torbox
    try:
        tb = Torbox()
        if tb.token:
            info = tb.account_info()
            if info:
                accounts.append({
                    'name': 'Torbox',
                    'configured': True,
                    'username': info.get('username', ''),
                    'email': info.get('email', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                })
            else:
                accounts.append({'name': 'Torbox', 'configured': True,
                                 'error': 'Could not fetch account info - try re-authorizing'})
        else:
            accounts.append({'name': 'Torbox', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'Torbox', 'configured': True, 'error': str(e)})
    
    # LinkSnappy
    try:
        ls = LinkSnappy()
        if ls.is_authorized():
            info = ls.account_info()
            if info:
                accounts.append({
                    'name': 'LinkSnappy',
                    'configured': True,
                    'username': info.get('username', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                })
            else:
                accounts.append({'name': 'LinkSnappy', 'configured': True,
                                 'error': 'Could not fetch account info - try re-logging in'})
        else:
            accounts.append({'name': 'LinkSnappy', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'LinkSnappy', 'configured': True, 'error': str(e)})
    
    return accounts



# ══════════════════════════════════════════════════════════════════════════════
# ██████  DEBRID CLOUD BROWSER  ████████████████████████████████████████████████
# ══════════════════════════════════════════════════════════════════════════════

def get_cloud_services():
    """Get list of authorized debrid services that support cloud browsing"""
    services = []
    
    rd = RealDebrid()
    if rd.is_authorized():
        services.append(('Real-Debrid', rd, 'rd'))
    
    pm = Premiumize()
    if pm.is_authorized():
        services.append(('Premiumize', pm, 'pm'))
    
    tb = Torbox()
    if tb.is_authorized():
        services.append(('Torbox', tb, 'tb'))
    
    ad = AllDebrid()
    if ad.is_authorized():
        services.append(('AllDebrid', ad, 'ad'))
    
    return services


def rd_get_torrents():
    """Get list of torrents/downloads from Real-Debrid cloud"""
    rd = RealDebrid()
    if not rd.is_authorized():
        return []
    
    try:
        status, result = _get(
            f"{rd.BASE_URL}/torrents",
            headers=rd._auth_headers()
        )
        
        if status == 200 and isinstance(result, list):
            items = []
            for item in result:
                torrent_id = item.get('id', '')
                filename = item.get('filename', 'Unknown')
                status_str = item.get('status', '')
                progress = item.get('progress', 0)
                bytes_size = item.get('bytes', 0)
                
                # Format size
                if bytes_size > 1073741824:  # GB
                    size_str = f"{bytes_size / 1073741824:.2f} GB"
                elif bytes_size > 1048576:  # MB
                    size_str = f"{bytes_size / 1048576:.1f} MB"
                else:
                    size_str = f"{bytes_size / 1024:.0f} KB"
                
                items.append({
                    'id': torrent_id,
                    'name': filename,
                    'status': status_str,
                    'progress': progress,
                    'size': size_str,
                    'bytes': bytes_size,
                    'service': 'rd'
                })
            return items
    except Exception as e:
        xbmc.log(f'RD cloud list error: {e}', xbmc.LOGERROR)
    
    return []


def rd_get_torrent_files(torrent_id):
    """Get files inside a Real-Debrid torrent"""
    rd = RealDebrid()
    if not rd.is_authorized():
        return []
    
    try:
        status, result = _get(
            f"{rd.BASE_URL}/torrents/info/{torrent_id}",
            headers=rd._auth_headers()
        )
        
        if status == 200 and isinstance(result, dict):
            files = []
            links = result.get('links', [])
            file_list = result.get('files', [])
            
            # Match links to files
            for i, link in enumerate(links):
                # Try to get filename from files list
                filename = f"File {i+1}"
                filesize = 0
                
                for f in file_list:
                    if f.get('selected') == 1:
                        filename = f.get('path', '').split('/')[-1] or filename
                        filesize = f.get('bytes', 0)
                        break
                
                # Format size
                if filesize > 1073741824:
                    size_str = f"{filesize / 1073741824:.2f} GB"
                elif filesize > 1048576:
                    size_str = f"{filesize / 1048576:.1f} MB"
                else:
                    size_str = f"{filesize / 1024:.0f} KB" if filesize > 0 else ""
                
                files.append({
                    'name': filename,
                    'link': link,
                    'size': size_str,
                    'bytes': filesize,
                    'service': 'rd'
                })
            
            return files
    except Exception as e:
        xbmc.log(f'RD torrent files error: {e}', xbmc.LOGERROR)
    
    return []


def rd_get_downloads():
    """Get download history from Real-Debrid"""
    rd = RealDebrid()
    if not rd.is_authorized():
        return []
    
    try:
        status, result = _get(
            f"{rd.BASE_URL}/downloads",
            params={"limit": 50},
            headers=rd._auth_headers()
        )
        
        if status == 200 and isinstance(result, list):
            items = []
            for item in result:
                filename = item.get('filename', 'Unknown')
                download_link = item.get('download', '')
                filesize = item.get('filesize', 0)
                generated = item.get('generated', '')
                
                # Format size
                if filesize > 1073741824:
                    size_str = f"{filesize / 1073741824:.2f} GB"
                elif filesize > 1048576:
                    size_str = f"{filesize / 1048576:.1f} MB"
                else:
                    size_str = f"{filesize / 1024:.0f} KB"
                
                # Check if it's a video file
                video_exts = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm']
                is_video = any(filename.lower().endswith(ext) for ext in video_exts)
                
                items.append({
                    'name': filename,
                    'link': download_link,
                    'size': size_str,
                    'bytes': filesize,
                    'date': generated[:10] if generated else '',
                    'is_video': is_video,
                    'service': 'rd'
                })
            return items
    except Exception as e:
        xbmc.log(f'RD downloads error: {e}', xbmc.LOGERROR)
    
    return []


def pm_get_cloud_files(folder_id=None):
    """Get files/folders from Premiumize cloud"""
    pm = Premiumize()
    if not pm.is_authorized():
        return []
    
    try:
        params = {}
        if folder_id:
            params['id'] = folder_id
        
        status, result = _get(
            f"{pm.BASE_URL}/folder/list",
            params=params,
            headers={"Authorization": f"Bearer {pm.token}"}
        )
        
        if status == 200 and isinstance(result, dict) and result.get('status') == 'success':
            items = []
            content = result.get('content', [])
            
            for item in content:
                item_type = item.get('type', '')
                name = item.get('name', 'Unknown')
                item_id = item.get('id', '')
                size = item.get('size', 0)
                link = item.get('link', '')
                
                # Format size
                if size > 1073741824:
                    size_str = f"{size / 1073741824:.2f} GB"
                elif size > 1048576:
                    size_str = f"{size / 1048576:.1f} MB"
                else:
                    size_str = f"{size / 1024:.0f} KB" if size > 0 else ""
                
                # Check if it's a video
                video_exts = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm']
                is_video = any(name.lower().endswith(ext) for ext in video_exts)
                
                items.append({
                    'id': item_id,
                    'name': name,
                    'type': item_type,  # 'folder' or 'file'
                    'link': link,
                    'size': size_str,
                    'bytes': size,
                    'is_video': is_video,
                    'service': 'pm'
                })
            
            return items
    except Exception as e:
        xbmc.log(f'PM cloud list error: {e}', xbmc.LOGERROR)
    
    return []


def pm_get_transfers():
    """Get active transfers from Premiumize"""
    pm = Premiumize()
    if not pm.is_authorized():
        return []
    
    try:
        status, result = _get(
            f"{pm.BASE_URL}/transfer/list",
            headers={"Authorization": f"Bearer {pm.token}"}
        )
        
        if status == 200 and isinstance(result, dict) and result.get('status') == 'success':
            items = []
            transfers = result.get('transfers', [])
            
            for item in transfers:
                name = item.get('name', 'Unknown')
                status_str = item.get('status', '')
                progress = item.get('progress', 0)
                folder_id = item.get('folder_id', '')
                file_id = item.get('file_id', '')
                
                items.append({
                    'id': folder_id or file_id,
                    'name': name,
                    'status': status_str,
                    'progress': int(progress * 100) if progress < 1 else int(progress),
                    'service': 'pm'
                })
            
            return items
    except Exception as e:
        xbmc.log(f'PM transfers error: {e}', xbmc.LOGERROR)
    
    return []


def tb_get_torrents():
    """Get torrents from Torbox cloud"""
    tb = Torbox()
    if not tb.is_authorized():
        return []
    
    try:
        status, result = _get(
            f"{tb.BASE_URL}/torrents/mylist",
            headers=tb._auth_headers()
        )
        
        if status == 200 and isinstance(result, dict) and result.get('success'):
            items = []
            data = result.get('data', [])
            
            if isinstance(data, dict):
                data = [data]
            
            for item in data:
                torrent_id = item.get('id', '')
                name = item.get('name', 'Unknown')
                status_str = item.get('download_state', '')
                progress = item.get('progress', 0)
                size = item.get('size', 0)
                
                # Format size
                if size > 1073741824:
                    size_str = f"{size / 1073741824:.2f} GB"
                elif size > 1048576:
                    size_str = f"{size / 1048576:.1f} MB"
                else:
                    size_str = f"{size / 1024:.0f} KB"
                
                items.append({
                    'id': torrent_id,
                    'name': name,
                    'status': status_str,
                    'progress': int(progress * 100) if progress <= 1 else int(progress),
                    'size': size_str,
                    'bytes': size,
                    'service': 'tb'
                })
            
            return items
    except Exception as e:
        xbmc.log(f'TB cloud list error: {e}', xbmc.LOGERROR)
    
    return []


def tb_get_torrent_files(torrent_id):
    """Get files inside a Torbox torrent"""
    tb = Torbox()
    if not tb.is_authorized():
        return []
    
    try:
        status, result = _get(
            f"{tb.BASE_URL}/torrents/mylist",
            params={"id": torrent_id},
            headers=tb._auth_headers()
        )
        
        if status == 200 and isinstance(result, dict) and result.get('success'):
            files = []
            data = result.get('data', {})
            
            if isinstance(data, list) and data:
                data = data[0]
            
            file_list = data.get('files', [])
            
            for f in file_list:
                file_id = f.get('id', 0)
                name = f.get('name', '').split('/')[-1] or f"File {file_id}"
                size = f.get('size', 0)
                
                # Format size
                if size > 1073741824:
                    size_str = f"{size / 1073741824:.2f} GB"
                elif size > 1048576:
                    size_str = f"{size / 1048576:.1f} MB"
                else:
                    size_str = f"{size / 1024:.0f} KB"
                
                # Check if video
                video_exts = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm']
                is_video = any(name.lower().endswith(ext) for ext in video_exts)
                
                files.append({
                    'id': file_id,
                    'torrent_id': torrent_id,
                    'name': name,
                    'size': size_str,
                    'bytes': size,
                    'is_video': is_video,
                    'service': 'tb'
                })
            
            return files
    except Exception as e:
        xbmc.log(f'TB torrent files error: {e}', xbmc.LOGERROR)
    
    return []


def tb_get_download_link(torrent_id, file_id):
    """Get download link for a Torbox file"""
    tb = Torbox()
    if not tb.is_authorized():
        return None
    
    try:
        status, result = _get(
            f"{tb.BASE_URL}/torrents/requestdl",
            params={"token": tb.token, "torrent_id": torrent_id, "file_id": file_id},
            headers=tb._auth_headers()
        )
        
        if status == 200 and isinstance(result, dict) and result.get('success'):
            return result.get('data')
    except Exception as e:
        xbmc.log(f'TB download link error: {e}', xbmc.LOGERROR)
    
    return None


def ad_get_magnets():
    """Get magnets/torrents from AllDebrid"""
    ad = AllDebrid()
    if not ad.is_authorized():
        return []
    
    try:
        status, result = _get(
            f"{ad.BASE_URL}/magnet/status",
            params={"agent": ad.AGENT, "apikey": ad.token}
        )
        
        if status == 200 and isinstance(result, dict) and result.get('status') == 'success':
            items = []
            magnets = result.get('data', {}).get('magnets', [])
            
            for item in magnets:
                magnet_id = item.get('id', '')
                filename = item.get('filename', 'Unknown')
                status_str = item.get('status', '')
                size = item.get('size', 0)
                
                # Format size
                if size > 1073741824:
                    size_str = f"{size / 1073741824:.2f} GB"
                elif size > 1048576:
                    size_str = f"{size / 1048576:.1f} MB"
                else:
                    size_str = f"{size / 1024:.0f} KB"
                
                items.append({
                    'id': magnet_id,
                    'name': filename,
                    'status': status_str,
                    'size': size_str,
                    'bytes': size,
                    'service': 'ad'
                })
            
            return items
    except Exception as e:
        xbmc.log(f'AD magnets list error: {e}', xbmc.LOGERROR)
    
    return []


def ad_get_magnet_files(magnet_id):
    """Get files inside an AllDebrid magnet"""
    ad = AllDebrid()
    if not ad.is_authorized():
        return []
    
    try:
        status, result = _get(
            f"{ad.BASE_URL}/magnet/status",
            params={"agent": ad.AGENT, "apikey": ad.token, "id": magnet_id}
        )
        
        if status == 200 and isinstance(result, dict) and result.get('status') == 'success':
            files = []
            magnet_data = result.get('data', {}).get('magnets', {})
            links = magnet_data.get('links', [])
            
            for link_info in links:
                filename = link_info.get('filename', 'Unknown')
                link = link_info.get('link', '')
                size = link_info.get('size', 0)
                
                # Format size
                if size > 1073741824:
                    size_str = f"{size / 1073741824:.2f} GB"
                elif size > 1048576:
                    size_str = f"{size / 1048576:.1f} MB"
                else:
                    size_str = f"{size / 1024:.0f} KB"
                
                # Check if video
                video_exts = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm']
                is_video = any(filename.lower().endswith(ext) for ext in video_exts)
                
                files.append({
                    'name': filename,
                    'link': link,
                    'size': size_str,
                    'bytes': size,
                    'is_video': is_video,
                    'service': 'ad'
                })
            
            return files
    except Exception as e:
        xbmc.log(f'AD magnet files error: {e}', xbmc.LOGERROR)
    
    return []


def delete_cloud_item(service, item_id):
    """Delete an item from debrid cloud"""
    try:
        if service == 'rd':
            rd = RealDebrid()
            if rd.is_authorized():
                status, _ = _http(
                    f"{rd.BASE_URL}/torrents/delete/{item_id}",
                    method='DELETE',
                    headers=rd._auth_headers()
                )
                return status == 204 or status == 200
        
        elif service == 'pm':
            pm = Premiumize()
            if pm.is_authorized():
                status, result = _post(
                    f"{pm.BASE_URL}/item/delete",
                    data={"id": item_id},
                    headers={"Authorization": f"Bearer {pm.token}"}
                )
                return status == 200 and isinstance(result, dict) and result.get('status') == 'success'
        
        elif service == 'tb':
            tb = Torbox()
            if tb.is_authorized():
                status, result = _http(
                    f"{tb.BASE_URL}/torrents/controltorrent",
                    method='POST',
                    data={"torrent_id": item_id, "operation": "delete"},
                    headers=tb._auth_headers()
                )
                return isinstance(result, dict) and result.get('success')
        
        elif service == 'ad':
            ad = AllDebrid()
            if ad.is_authorized():
                status, result = _get(
                    f"{ad.BASE_URL}/magnet/delete",
                    params={"agent": ad.AGENT, "apikey": ad.token, "id": item_id}
                )
                return isinstance(result, dict) and result.get('status') == 'success'
    
    except Exception as e:
        xbmc.log(f'Delete cloud item error: {e}', xbmc.LOGERROR)
    
    return False
